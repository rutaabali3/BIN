import { useState, useEffect } from 'react'
import { Menu, X, Home, BarChart3, TrendingUp, BookOpen, Mail, Phone, MapPin } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import HomePage from './components/HomePage.jsx'
import StatisticsPage from './components/StatisticsPage.jsx'
import BenefitsPage from './components/BenefitsPage.jsx'
import BestPracticesPage from './components/BestPracticesPage.jsx'
import './App.css'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [currentPage, setCurrentPage] = useState('home')

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navigateToPage = (page) => {
    setCurrentPage(page)
    setIsMenuOpen(false)
    window.scrollTo(0, 0)
  }

  const scrollToSection = (sectionId) => {
    if (currentPage !== 'home') {
      setCurrentPage('home')
      setTimeout(() => {
        const element = document.getElementById(sectionId)
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' })
        }
      }, 100)
    } else {
      const element = document.getElementById(sectionId)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }
    setIsMenuOpen(false)
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={navigateToPage} />
      case 'statistics':
        return <StatisticsPage />
      case 'benefits':
        return <BenefitsPage />
      case 'best-practices':
        return <BestPracticesPage />
      default:
        return <HomePage onNavigate={navigateToPage} />
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <button 
                onClick={() => navigateToPage('home')}
                className="text-2xl font-bold text-blue-700 hover:text-blue-800 transition-colors"
              >
                MobileFirst
              </button>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => navigateToPage('home')} 
                className={`flex items-center space-x-1 transition-colors ${
                  currentPage === 'home' ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                }`}
              >
                <Home size={18} />
                <span>Home</span>
              </button>
              <button 
                onClick={() => navigateToPage('statistics')} 
                className={`flex items-center space-x-1 transition-colors ${
                  currentPage === 'statistics' ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                }`}
              >
                <BarChart3 size={18} />
                <span>Statistics</span>
              </button>
              <button 
                onClick={() => navigateToPage('benefits')} 
                className={`flex items-center space-x-1 transition-colors ${
                  currentPage === 'benefits' ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                }`}
              >
                <TrendingUp size={18} />
                <span>Benefits</span>
              </button>
              <button 
                onClick={() => navigateToPage('best-practices')} 
                className={`flex items-center space-x-1 transition-colors ${
                  currentPage === 'best-practices' ? 'text-blue-700' : 'text-gray-700 hover:text-blue-700'
                }`}
              >
                <BookOpen size={18} />
                <span>Best Practices</span>
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="text-gray-700 hover:text-blue-700 transition-colors"
              >
                Contact
              </button>
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-blue-700 transition-colors p-2"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-white border-t border-gray-200">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <button 
                  onClick={() => navigateToPage('home')} 
                  className={`flex items-center space-x-2 w-full text-left px-3 py-2 transition-colors ${
                    currentPage === 'home' ? 'text-blue-700 bg-blue-50' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  <Home size={18} />
                  <span>Home</span>
                </button>
                <button 
                  onClick={() => navigateToPage('statistics')} 
                  className={`flex items-center space-x-2 w-full text-left px-3 py-2 transition-colors ${
                    currentPage === 'statistics' ? 'text-blue-700 bg-blue-50' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  <BarChart3 size={18} />
                  <span>Statistics</span>
                </button>
                <button 
                  onClick={() => navigateToPage('benefits')} 
                  className={`flex items-center space-x-2 w-full text-left px-3 py-2 transition-colors ${
                    currentPage === 'benefits' ? 'text-blue-700 bg-blue-50' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  <TrendingUp size={18} />
                  <span>Benefits</span>
                </button>
                <button 
                  onClick={() => navigateToPage('best-practices')} 
                  className={`flex items-center space-x-2 w-full text-left px-3 py-2 transition-colors ${
                    currentPage === 'best-practices' ? 'text-blue-700 bg-blue-50' : 'text-gray-700 hover:text-blue-700'
                  }`}
                >
                  <BookOpen size={18} />
                  <span>Best Practices</span>
                </button>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="block w-full text-left px-3 py-2 text-gray-700 hover:text-blue-700 transition-colors"
                >
                  Contact
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>
        {renderCurrentPage()}
      </main>

      {/* Contact Section - Always visible */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Ready to create an amazing mobile-first experience? Let's discuss your project.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-gray-800 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-6">Send us a message</h3>
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-transparent"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-transparent"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-transparent"
                    placeholder="Tell us about your project..."
                  ></textarea>
                </div>
                <Button className="w-full bg-blue-700 hover:bg-blue-800 text-white py-3">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-700 p-3 rounded-lg">
                  <Mail className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Email</h3>
                  <p className="text-gray-300">hello@mobilefirst.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-blue-700 p-3 rounded-lg">
                  <Phone className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Phone</h3>
                  <p className="text-gray-300">+1 (555) 123-4567</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-blue-700 p-3 rounded-lg">
                  <MapPin className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Location</h3>
                  <p className="text-gray-300">San Francisco, CA</p>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Why Choose Mobile-First?</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• 58% of web traffic is mobile</li>
                  <li>• 9,900% ROI on UX investment</li>
                  <li>• 83% conversion rate increase possible</li>
                  <li>• Future-proof your digital presence</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-2xl font-bold mb-4 text-blue-700">MobileFirst</h3>
              <p className="text-gray-400 mb-4">
                Creating exceptional mobile-first experiences that work beautifully across all devices.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><button onClick={() => navigateToPage('home')} className="text-gray-400 hover:text-white transition-colors">Home</button></li>
                <li><button onClick={() => navigateToPage('statistics')} className="text-gray-400 hover:text-white transition-colors">Statistics</button></li>
                <li><button onClick={() => navigateToPage('benefits')} className="text-gray-400 hover:text-white transition-colors">Benefits</button></li>
                <li><button onClick={() => navigateToPage('best-practices')} className="text-gray-400 hover:text-white transition-colors">Best Practices</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Twitter</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">LinkedIn</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">GitHub</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Dribbble</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 MobileFirst. All rights reserved. Built with React and Tailwind CSS.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

