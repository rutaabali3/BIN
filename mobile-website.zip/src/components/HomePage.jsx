import { Smartphone, ArrowRight, TrendingUp, Users, Globe } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import heroImage from '../assets/hero-mobile-design.webp'
import mobileUIImage from '../assets/mobile-ui-design.webp'

function HomePage({ onNavigate }) {
  return (
    <div>
      {/* Hero Section with Images */}
      <section id="home" className="pt-20 pb-16 bg-gradient-to-br from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Mobile-First <span className="text-blue-700">Design</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Experience the future of responsive web design with our mobile-optimized approach that delivers exceptional user experiences across all devices.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => onNavigate('statistics')}
                  className="bg-blue-700 hover:bg-blue-800 text-white px-8 py-3 text-lg"
                >
                  View Statistics <ArrowRight className="ml-2" size={20} />
                </Button>
                <Button 
                  onClick={() => onNavigate('benefits')}
                  variant="outline" 
                  className="border-blue-700 text-blue-700 hover:bg-blue-50 px-8 py-3 text-lg"
                >
                  Learn Benefits
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src={heroImage} 
                alt="Mobile Design Showcase" 
                className="w-full h-auto rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Smartphone className="text-blue-700" size={24} />
                  <span className="font-semibold text-gray-900">Mobile-First</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Statistics Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Why Mobile Design Matters
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The numbers speak for themselves - mobile design is no longer optional
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">58%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Global Mobile Traffic</h3>
              <p className="text-gray-600">
                Mobile devices account for over half of all web traffic worldwide
              </p>
            </div>

            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">88%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">User Retention</h3>
              <p className="text-gray-600">
                Users are less likely to return after a bad mobile experience
              </p>
            </div>

            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">9,900%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">ROI on UX</h3>
              <p className="text-gray-600">
                Every $1 invested in UX returns $100 in business value
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button 
              onClick={() => onNavigate('statistics')}
              className="bg-blue-700 hover:bg-blue-800 text-white px-8 py-3"
            >
              View All Statistics
            </Button>
          </div>
        </div>
      </section>

      {/* Mobile UI Showcase */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src={mobileUIImage} 
                alt="Mobile User Interface Design" 
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
                Modern Mobile Interfaces
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Today's mobile interfaces require thoughtful design that prioritizes user experience, 
                performance, and accessibility across all devices and screen sizes.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2"></div>
                  <p className="text-gray-600">Touch-optimized interactions and gestures</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2"></div>
                  <p className="text-gray-600">Responsive layouts that adapt to any screen</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2"></div>
                  <p className="text-gray-600">Fast loading times and smooth animations</p>
                </div>
              </div>
              <div className="mt-8">
                <Button 
                  onClick={() => onNavigate('best-practices')}
                  className="bg-blue-700 hover:bg-blue-800 text-white"
                >
                  Learn Best Practices
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

