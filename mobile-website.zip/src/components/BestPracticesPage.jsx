import { Smartphone, Zap, Layout, Accessibility, Code, CheckCircle } from 'lucide-react'

function BestPracticesPage() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 bg-gradient-to-br from-blue-700 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6">
            Mobile Design Best Practices
          </h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Essential guidelines and strategies for implementing effective mobile-first design
          </p>
        </div>
      </section>

      {/* Core Principles */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Core Design Principles
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Smartphone className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">Mobile-First Approach</h3>
              <p className="text-gray-600 text-center mb-4">
                Start designing for the smallest screen first, then progressively enhance for larger devices.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Design for 320px width minimum
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Prioritize essential content
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Progressive enhancement strategy
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Layout className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">Responsive Layout</h3>
              <p className="text-gray-600 text-center mb-4">
                Create flexible layouts that adapt seamlessly to different screen sizes and orientations.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Flexible grid systems
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Fluid typography scaling
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Adaptive image sizing
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 text-center mb-4">Performance First</h3>
              <p className="text-gray-600 text-center mb-4">
                Optimize for speed and efficiency to ensure fast loading times on mobile networks.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Minimize HTTP requests
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Optimize images and assets
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Lazy loading implementation
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Implementation */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Technical Implementation
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Code className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Responsive Breakpoints</h3>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Mobile (320px - 768px)</h4>
                  <p className="text-gray-600 text-sm">
                    Single column layout, large touch targets, simplified navigation
                  </p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Tablet (768px - 1024px)</h4>
                  <p className="text-gray-600 text-sm">
                    Two-column layouts, expanded navigation, medium-sized touch targets
                  </p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Desktop (1024px+)</h4>
                  <p className="text-gray-600 text-sm">
                    Multi-column layouts, hover states, full navigation menus
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Accessibility className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Touch Optimization</h3>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Minimum touch target size</span>
                  <span className="font-bold text-blue-700">44px × 44px</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Spacing between targets</span>
                  <span className="font-bold text-blue-700">8px minimum</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Thumb-friendly zone</span>
                  <span className="font-bold text-blue-700">Bottom 1/3</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Gesture support</span>
                  <span className="font-bold text-blue-700">Swipe, pinch, tap</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Performance Guidelines */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Performance Optimization
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Loading Speed</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Target under 3 seconds load time
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Optimize critical rendering path
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Minimize render-blocking resources
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Image Optimization</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Use modern formats (WebP, AVIF)
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Implement responsive images
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Lazy load below-fold content
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Network Efficiency</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Minimize payload size
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Enable compression (Gzip/Brotli)
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                  Use CDN for static assets
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* UX Best Practices */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            User Experience Guidelines
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Navigation Design</h3>
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Hamburger Menu</h4>
                  <p className="text-gray-600 text-sm">
                    Use for secondary navigation, keep primary actions visible
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Tab Navigation</h4>
                  <p className="text-gray-600 text-sm">
                    Limit to 5 tabs maximum, use clear icons and labels
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Breadcrumbs</h4>
                  <p className="text-gray-600 text-sm">
                    Essential for deep navigation structures and user orientation
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Content Strategy</h3>
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Content Hierarchy</h4>
                  <p className="text-gray-600 text-sm">
                    Prioritize essential information, use progressive disclosure
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Readable Typography</h4>
                  <p className="text-gray-600 text-sm">
                    Minimum 16px font size, high contrast, adequate line spacing
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow">
                  <h4 className="font-semibold text-gray-900 mb-2">Scannable Layout</h4>
                  <p className="text-gray-600 text-sm">
                    Use bullet points, short paragraphs, clear headings
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testing & Validation */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Testing & Validation
          </h2>

          <div className="bg-gradient-to-br from-blue-50 to-gray-50 p-8 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Device Testing</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Test on real devices, not just emulators
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Cover major screen sizes and resolutions
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Test both portrait and landscape orientations
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Validate touch interactions and gestures
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Performance Metrics</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Monitor Core Web Vitals (LCP, FID, CLS)
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Test on slow 3G networks
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Validate accessibility compliance
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="text-blue-700 mr-2 mt-1" size={16} />
                    Conduct usability testing with real users
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default BestPracticesPage

