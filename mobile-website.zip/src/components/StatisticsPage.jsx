import { TrendingUp, Smartphone, DollarSign, Users, Clock, ShoppingCart, Star, BarChart3 } from 'lucide-react'

function StatisticsPage() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 bg-gradient-to-br from-blue-700 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6">
            Mobile Design Statistics
          </h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Comprehensive data that proves the critical importance of mobile-first design in today's digital landscape
          </p>
        </div>
      </section>

      {/* Key Statistics Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Mobile Traffic */}
            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">58%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Global Mobile Traffic</h3>
              <p className="text-gray-600 text-sm">
                Mobile devices account for over half of all global web traffic
              </p>
            </div>

            {/* Mobile Commerce */}
            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingCart className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">45%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Mobile Commerce</h3>
              <p className="text-gray-600 text-sm">
                Mobile transactions represent 45% of all e-commerce sales
              </p>
            </div>

            {/* User Abandonment */}
            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">53%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Abandonment Rate</h3>
              <p className="text-gray-600 text-sm">
                Users abandon sites that take longer than 3 seconds to load
              </p>
            </div>

            {/* ROI */}
            <div className="text-center bg-gray-50 p-8 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="text-blue-700" size={32} />
              </div>
              <div className="text-4xl font-bold text-blue-700 mb-2">9,900%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">UX ROI</h3>
              <p className="text-gray-600 text-sm">
                Every $1 invested in UX returns $100 in business value
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Statistics */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Detailed Mobile UX Statistics
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* User Behavior */}
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Users className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">User Behavior</h3>
              </div>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Users spending 4.5+ hours daily on mobile</span>
                  <span className="text-2xl font-bold text-blue-700">20%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Users less likely to return after bad UX</span>
                  <span className="text-2xl font-bold text-blue-700">88%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Mobile users 5x more likely to abandon non-optimized sites</span>
                  <span className="text-2xl font-bold text-blue-700">5x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Users expecting seamless cross-device experience</span>
                  <span className="text-2xl font-bold text-blue-700">83%</span>
                </div>
              </div>
            </div>

            {/* Business Impact */}
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <BarChart3 className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Business Impact</h3>
              </div>
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Conversion increase with 10% UX budget boost</span>
                  <span className="text-2xl font-bold text-blue-700">83%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Companies with top design grow faster</span>
                  <span className="text-2xl font-bold text-blue-700">2x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">UX design can triple conversion rates</span>
                  <span className="text-2xl font-bold text-blue-700">3x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Users willing to pay more for better UX</span>
                  <span className="text-2xl font-bold text-blue-700">80%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mobile App Statistics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Mobile App Performance
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Smartphone className="text-blue-700" size={40} />
              </div>
              <div className="text-3xl font-bold text-blue-700 mb-2">24%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Daily Uninstalls</h3>
              <p className="text-gray-600">
                Android apps uninstalled within one day of download
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="text-blue-700" size={40} />
              </div>
              <div className="text-3xl font-bold text-blue-700 mb-2">74%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Return Rate</h3>
              <p className="text-gray-600">
                Visitors likely to return to sites with good mobile UX
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-blue-700" size={40} />
              </div>
              <div className="text-3xl font-bold text-blue-700 mb-2">90%</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Continued Shopping</h3>
              <p className="text-gray-600">
                Smartphone users continue shopping with great UX
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Performance Statistics */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Performance Impact
          </h2>

          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Loading Time Impact</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Users stop engaging with slow content</span>
                    <span className="font-bold text-blue-700">39%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Conversion increase per second improvement</span>
                    <span className="font-bold text-blue-700">2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Mobile site should match desktop quality</span>
                    <span className="font-bold text-blue-700">85%</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">User Expectations</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Users sharing positive experiences</span>
                    <span className="font-bold text-blue-700">23%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">More likely to buy with relevant recommendations</span>
                    <span className="font-bold text-blue-700">63%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">View companies favorably with memory features</span>
                    <span className="font-bold text-blue-700">58%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default StatisticsPage

