import { TrendingUp, Search, Zap, Shield, Globe, Users, Star, Target } from 'lucide-react'

function BenefitsPage() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 bg-gradient-to-br from-blue-700 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6">
            Mobile-First Benefits
          </h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Discover the transformative advantages of adopting a mobile-first design strategy for your business
          </p>
        </div>
      </section>

      {/* Core Benefits */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Core Business Benefits
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Improved User Experience */}
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Users className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Improved User Experience</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Mobile-first design prioritizes delivering the best experience to the majority of your users, 
                ultimately fostering higher satisfaction, engagement, and loyalty among your customers.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Higher customer satisfaction rates
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Increased user engagement and time on site
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Enhanced customer loyalty and retention
                </li>
              </ul>
            </div>

            {/* Better Search Rankings */}
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Search className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Better Search Engine Rankings</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Major search engines like Google prioritize mobile-friendly websites in search results, 
                significantly improving your search engine rankings and online visibility.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Higher search result rankings
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Increased organic traffic
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Better discoverability by potential customers
                </li>
              </ul>
            </div>

            {/* Increased Conversion Rates */}
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Target className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Increased Conversion Rates</h3>
              </div>
              <p className="text-gray-600 mb-4">
                An optimized mobile experience benefits from faster loading times and a user-friendly interface, 
                both crucial factors that influence users' decision-making processes.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Higher conversion rates and sales
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Reduced cart abandonment
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Increased revenue per visitor
                </li>
              </ul>
            </div>

            {/* Future-Proofing */}
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 p-3 rounded-lg mr-4">
                  <Shield className="text-blue-700" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Future-Proofing Your Website</h3>
              </div>
              <p className="text-gray-600 mb-4">
                As the trend towards mobile reliance continues to grow, ensuring that your website is 
                optimized for mobile use allows you to stay ahead of the curve.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Adaptability to emerging technologies
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Competitive advantage in digital landscape
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-700 w-2 h-2 rounded-full mt-2 mr-3"></div>
                  Long-term sustainability
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Performance Benefits */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Performance & Technical Benefits
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Faster Loading Times</h3>
              <p className="text-gray-600">
                Mobile-first design emphasizes performance optimization, resulting in faster loading times 
                that improve user experience and search rankings.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Cross-Device Compatibility</h3>
              <p className="text-gray-600">
                Ensures seamless functionality across all devices and screen sizes, providing 
                consistent user experience regardless of how users access your site.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="text-blue-700" size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Enhanced Accessibility</h3>
              <p className="text-gray-600">
                Mobile-first design naturally incorporates accessibility principles, making your 
                website usable by people with diverse abilities and circumstances.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Business Impact Metrics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Measurable Business Impact
          </h2>

          <div className="bg-gradient-to-br from-blue-50 to-gray-50 p-8 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-blue-700 mb-2">83%</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Conversion Increase</h3>
                <p className="text-gray-600 text-sm">
                  With 10% UX budget boost
                </p>
              </div>

              <div className="text-center">
                <div className="text-4xl font-bold text-blue-700 mb-2">2x</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Growth Rate</h3>
                <p className="text-gray-600 text-sm">
                  Companies with top design practices
                </p>
              </div>

              <div className="text-center">
                <div className="text-4xl font-bold text-blue-700 mb-2">3x</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Conversion Rates</h3>
                <p className="text-gray-600 text-sm">
                  With well-executed UX design
                </p>
              </div>

              <div className="text-center">
                <div className="text-4xl font-bold text-blue-700 mb-2">80%</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Premium Willingness</h3>
                <p className="text-gray-600 text-sm">
                  Users pay more for better UX
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Competitive Advantages */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Competitive Advantages
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Stay Ahead of the Competition
              </h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-700 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Market Leadership</h4>
                    <p className="text-gray-600">
                      Position your business as a forward-thinking leader in the digital space
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-blue-700 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Customer Acquisition</h4>
                    <p className="text-gray-600">
                      Attract and retain customers with superior mobile experiences
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-blue-700 w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Brand Differentiation</h4>
                    <p className="text-gray-600">
                      Stand out from competitors with exceptional mobile design quality
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
                Why Mobile-First Wins
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Users prefer mobile-optimized sites</span>
                  <span className="text-lg font-bold text-blue-700">85%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Expect seamless cross-device experience</span>
                  <span className="text-lg font-bold text-blue-700">83%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">More likely to return with good mobile UX</span>
                  <span className="text-lg font-bold text-blue-700">74%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Continue shopping with great UX</span>
                  <span className="text-lg font-bold text-blue-700">90%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default BenefitsPage

