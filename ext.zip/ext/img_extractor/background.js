chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "downloadImages") {
    const { images, folder } = request;
    images.forEach((url, index) => {
      const filename = url.split('/').pop().split('?')[0] || `image_${index}.jpg`;
      const path = folder ? `${folder}/${filename}` : filename;
      
      chrome.downloads.download({
        url: url,
        filename: path,
        conflictAction: 'uniquify'
      });
    });
    sendResponse({ success: true });
  }
});
