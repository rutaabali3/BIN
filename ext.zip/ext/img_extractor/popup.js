// Mock Chrome Extension API for browser/headless testing environments (e.g. Playwright)
if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.onMessage) {
  window.chrome = {
    tabs: {
      query: async (queryInfo) => {
        return [{ id: 1, url: 'https://images.unsplash.com' }];
      },
      sendMessage: (tabId, message, callback) => {
        if (message && message.action === "getImages") {
          // Provide some real, beautiful image URLs from Unsplash for testing
          setTimeout(() => {
            callback({
              images: [
                "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=400&auto=format&fit=crop", // Colorful abstract gradient
                "https://images.unsplash.com/photo-1533038590840-1cde6b66b733?w=400&auto=format&fit=crop", // Plain wall grey
                "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&auto=format&fit=crop"  // Beach sunset
              ]
            });
          }, 50);
        }
      }
    },
    scripting: {
      executeScript: async (info) => {
        return [{ result: true }];
      }
    },
    downloads: {
      download: (options, callback) => {
        console.log("Mock download called with options:", options);
        if (callback) {
          setTimeout(() => callback(12345), 50);
        }
      }
    },
    runtime: {
      sendMessage: (message, callback) => {
        console.log("Mock runtime.sendMessage called with:", message);
        if (callback) {
          setTimeout(() => callback({ success: true }), 50);
        }
      }
    }
  };
}

let allImages = [];
let filteredImages = [];
let selectedImages = new Set();
let currentSizeFilter = '';

// Background Remover state
let loadedRemoverUrl = '';
let sourceImage = null;
let originalImageData = null;
let selectedKeyColor = [255, 255, 255]; // default white
let tolerance = 15;
let feather = 2;

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://')) {
    document.getElementById('image-grid').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔒</div>
        <div>Cannot access browser internal pages.</div>
      </div>`;
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
    
    chrome.tabs.sendMessage(tab.id, { action: "getImages" }, (response) => {
      if (response && response.images) {
        allImages = response.images;
        filteredImages = [...allImages];
        renderImages();
      } else {
        document.getElementById('image-grid').innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon">🖼️</div>
            <div>No images found. Try refreshing the page.</div>
          </div>`;
      }
    });
  } catch (err) {
    console.error("Failed to execute script: ", err);
    document.getElementById('image-grid').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <div>Failed to access this page. Make sure it's fully loaded.</div>
      </div>`;
  }
}

function getImageSize(url) {
  if (url.includes('thumb') || url.includes('small') || url.includes('avatar')) return 'small';
  if (url.includes('large') || url.includes('hd') || url.includes('full') || url.includes('original')) return 'large';
  return 'medium';
}

function applyFilters() {
  const urlFilter = document.getElementById('urlFilter').value.toLowerCase();

  filteredImages = allImages.filter(url => {
    if (currentSizeFilter) {
      const imgSize = getImageSize(url);
      if (imgSize !== currentSizeFilter) return false;
    }

    if (urlFilter && !url.toLowerCase().includes(urlFilter)) {
      return false;
    }

    return true;
  });

  renderImages();
}

function renderImages() {
  const grid = document.getElementById('image-grid');
  const countSpan = document.getElementById('count');
  grid.innerHTML = '';
  countSpan.innerText = filteredImages.length;

  if (filteredImages.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <div>No matching images found.</div>
      </div>`;
    return;
  }

  filteredImages.forEach((url) => {
    const item = document.createElement('div');
    item.className = 'image-item';
    if (selectedImages.has(url)) {
      item.classList.add('selected');
    }
    item.dataset.url = url;
    
    // Custom checkbox overlay
    const checkbox = document.createElement('div');
    checkbox.className = 'checkbox-overlay';

    // Magic Background Remover button
    const magicBtn = document.createElement('button');
    magicBtn.className = 'magic-btn-overlay';
    magicBtn.innerHTML = '✨';
    magicBtn.title = 'Remove Background';
    magicBtn.onclick = (e) => {
      e.stopPropagation();
      openBackgroundRemover(url);
    };

    const img = document.createElement('img');
    img.src = url;
    img.loading = 'lazy';
    img.onerror = () => {
      img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23e8e8e8" width="100" height="100"/%3E%3Ctext x="50" y="50" text-anchor="middle" dy=".3em" fill="%23999" font-size="12"%3E?%3C/text%3E%3C/svg%3E';
    };

    item.appendChild(checkbox);
    item.appendChild(magicBtn);
    item.appendChild(img);

    item.onclick = () => {
      const isSelected = !selectedImages.has(url);
      toggleSelect(url, item, isSelected);
    };

    grid.appendChild(item);
  });
}

function toggleSelect(url, element, isSelected) {
  if (isSelected) {
    selectedImages.add(url);
    element.classList.add('selected');
  } else {
    selectedImages.delete(url);
    element.classList.remove('selected');
  }
}

// Setup chip filter click handlers
document.querySelectorAll('#sizeChips .chip').forEach(chip => {
  chip.onclick = (e) => {
    document.querySelectorAll('#sizeChips .chip').forEach(c => c.classList.remove('selected'));
    chip.classList.add('selected');
    currentSizeFilter = chip.dataset.value;
    applyFilters();
  };
});

document.getElementById('selectAll').onclick = () => {
  const items = document.querySelectorAll('.image-item');
  const anyUnselected = filteredImages.some(url => !selectedImages.has(url));
  
  filteredImages.forEach((url, i) => {
    if (anyUnselected) {
      selectedImages.add(url);
      if (items[i]) items[i].classList.add('selected');
    } else {
      selectedImages.delete(url);
      if (items[i]) items[i].classList.remove('selected');
    }
  });
};

document.getElementById('refreshBtn').onclick = () => {
  selectedImages.clear();
  init();
};

document.getElementById('urlFilter').addEventListener('input', applyFilters);

// Helper to fetch and load image securely without CORS contamination
async function loadImageSecurely(url) {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        resolve({ img, objectUrl });
      };
      img.onerror = () => {
        reject(new Error("Failed to load image"));
      };
      img.src = objectUrl;
    });
  } catch (e) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        resolve({ img, objectUrl: null });
      };
      img.onerror = () => {
        reject(new Error("CORS fallback failed"));
      };
      img.src = url;
    });
  }
}

// Convert image format and download
async function downloadAndConvertImage(url, targetFormat, index) {
  const originalFilename = url.split('/').pop().split('?')[0] || `image_${index}.jpg`;
  const baseName = originalFilename.substring(0, originalFilename.lastIndexOf('.')) || originalFilename;
  
  if (targetFormat === 'original') {
    chrome.downloads.download({
      url: url,
      filename: `Rutaabs_downloads/${originalFilename}`,
      conflictAction: 'uniquify'
    });
    return;
  }

  try {
    const { img, objectUrl } = await loadImageSecurely(url);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || img.width || 400;
    canvas.height = img.naturalHeight || img.height || 400;
    
    const ctx = canvas.getContext('2d');
    
    if (targetFormat === 'jpeg') {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    
    ctx.drawImage(img, 0, 0);
    
    const mimeType = `image/${targetFormat}`;
    const dataUrl = canvas.toDataURL(mimeType, 0.95);
    
    chrome.downloads.download({
      url: dataUrl,
      filename: `Rutaabs_downloads/${baseName}.${targetFormat}`,
      conflictAction: 'uniquify'
    });
    
    if (objectUrl) {
      URL.revokeObjectURL(objectUrl);
    }
  } catch (e) {
    console.error("Format conversion failed, downloading original fallback", e);
    chrome.downloads.download({
      url: url,
      filename: `Rutaabs_downloads/${originalFilename}`,
      conflictAction: 'uniquify'
    });
  }
}

document.getElementById('downloadBtn').onclick = async () => {
  if (selectedImages.size === 0) {
    alert("Please select images to download.");
    return;
  }
  
  const targetFormat = document.getElementById('downloadFormat').value;
  const imagesArray = Array.from(selectedImages);
  
  alert(`Converting and downloading ${selectedImages.size} images...`);
  
  for (let i = 0; i < imagesArray.length; i++) {
    await downloadAndConvertImage(imagesArray[i], targetFormat, i);
  }
  
  selectedImages.clear();
  renderImages();
};

/* ------------------------------------------------------------- */
/* BACKGROUND REMOVER VIEW LOGIC                                 */
/* ------------------------------------------------------------- */
const removerOverlay = document.getElementById('removerOverlay');
const removerCanvas = document.getElementById('removerCanvas');
const removerCtx = removerCanvas.getContext('2d');

async function openBackgroundRemover(url) {
  loadedRemoverUrl = url;
  removerOverlay.classList.add('open');
  
  // Reset fields
  document.getElementById('toleranceSlider').value = 15;
  document.getElementById('toleranceVal').innerText = '15%';
  tolerance = 15;
  
  document.getElementById('featherSlider').value = 2;
  document.getElementById('featherVal').innerText = '2px';
  feather = 2;
  
  document.getElementById('colorSwatch').style.backgroundColor = 'transparent';
  document.getElementById('colorHex').innerText = 'Click canvas to pick background';
  
  removerCtx.clearRect(0, 0, removerCanvas.width, removerCanvas.height);
  
  try {
    const { img, objectUrl } = await loadImageSecurely(url);
    sourceImage = img;
    
    // Set canvas dimensions
    const maxDimension = 320;
    let w = img.naturalWidth || img.width || 300;
    let h = img.naturalHeight || img.height || 300;
    
    const ratio = w / h;
    if (w > h) {
      if (w > maxDimension) {
        w = maxDimension;
        h = Math.round(w / ratio);
      }
    } else {
      if (h > maxDimension) {
        h = maxDimension;
        w = Math.round(h * ratio);
      }
    }
    
    removerCanvas.width = w;
    removerCanvas.height = h;
    
    removerCtx.drawImage(sourceImage, 0, 0, w, h);
    originalImageData = removerCtx.getImageData(0, 0, w, h);
    
    // Clean up temporary URL
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    
    // Default key color: auto-detect!
    autoDetectBG();
  } catch (err) {
    console.error("Failed to load image in background remover", err);
    alert("Could not load image details.");
    removerOverlay.classList.remove('open');
  }
}

function getPixelColor(x, y) {
  if (!originalImageData) return [255, 255, 255];
  const width = removerCanvas.width;
  const index = (y * width + x) * 4;
  const data = originalImageData.data;
  return [data[index], data[index + 1], data[index + 2]];
}

function updateColorIndicator(color) {
  const hex = "#" + color.map(c => c.toString(16).padStart(2, '0')).join('').toUpperCase();
  document.getElementById('colorSwatch').style.backgroundColor = hex;
  document.getElementById('colorHex').innerText = `Color: ${hex}`;
}

// Background removal pixel math
function renderBackgroundRemoval() {
  if (!originalImageData) return;
  
  const width = removerCanvas.width;
  const height = removerCanvas.height;
  const outputImageData = removerCtx.createImageData(width, height);
  
  const src = originalImageData.data;
  const dest = outputImageData.data;
  
  const [keyR, keyG, keyB] = selectedKeyColor;
  const tol = tolerance / 100;
  // Map feather value (0-10 px) to a normalized range
  const ftr = feather / 50; 
  
  for (let i = 0; i < src.length; i += 4) {
    const r = src[i];
    const g = src[i + 1];
    const b = src[i + 2];
    const a = src[i + 3];
    
    // Euclidean distance in RGB color space
    const diffR = r - keyR;
    const diffG = g - keyG;
    const diffB = b - keyB;
    const distance = Math.sqrt(diffR * diffR + diffG * diffG + diffB * diffB);
    const normDistance = distance / 441.67; // sqrt(255*255*3) = 441.67
    
    let alpha = a;
    
    if (normDistance < tol) {
      alpha = 0;
    } else if (normDistance < tol + ftr && ftr > 0) {
      const scale = (normDistance - tol) / ftr;
      alpha = Math.round(a * scale);
    }
    
    dest[i] = r;
    dest[i+1] = g;
    dest[i+2] = b;
    dest[i+3] = alpha;
  }
  
  removerCtx.putImageData(outputImageData, 0, 0);
}

function autoDetectBG() {
  if (!originalImageData) return;
  const w = removerCanvas.width;
  const h = removerCanvas.height;
  
  // Sample corners: top-left, top-right, bottom-left, bottom-right
  const c1 = getPixelColor(0, 0);
  const c2 = getPixelColor(w - 1, 0);
  const c3 = getPixelColor(0, h - 1);
  const c4 = getPixelColor(w - 1, h - 1);
  
  // Average the corners to find a baseline key color
  selectedKeyColor = [
    Math.round((c1[0] + c2[0] + c3[0] + c4[0]) / 4),
    Math.round((c1[1] + c2[1] + c3[1] + c4[1]) / 4),
    Math.round((c1[2] + c2[2] + c3[2] + c4[2]) / 4)
  ];
  
  updateColorIndicator(selectedKeyColor);
  renderBackgroundRemoval();
}

// Binds
document.getElementById('removerBackBtn').onclick = () => {
  removerOverlay.classList.remove('open');
};

removerCanvas.onclick = (e) => {
  const rect = removerCanvas.getBoundingClientRect();
  const scaleX = removerCanvas.width / rect.width;
  const scaleY = removerCanvas.height / rect.height;
  
  const x = Math.min(removerCanvas.width - 1, Math.max(0, Math.round((e.clientX - rect.left) * scaleX)));
  const y = Math.min(removerCanvas.height - 1, Math.max(0, Math.round((e.clientY - rect.top) * scaleY)));
  
  selectedKeyColor = getPixelColor(x, y);
  updateColorIndicator(selectedKeyColor);
  renderBackgroundRemoval();
};

document.getElementById('toleranceSlider').oninput = (e) => {
  tolerance = parseInt(e.target.value);
  document.getElementById('toleranceVal').innerText = `${tolerance}%`;
  renderBackgroundRemoval();
};

document.getElementById('featherSlider').oninput = (e) => {
  feather = parseInt(e.target.value);
  document.getElementById('featherVal').innerText = `${feather}px`;
  renderBackgroundRemoval();
};

document.getElementById('autoDetectBtn').onclick = () => {
  autoDetectBG();
};

document.getElementById('saveRemoverBtn').onclick = () => {
  const format = document.getElementById('removerFormat').value;
  const originalFilename = loadedRemoverUrl.split('/').pop().split('?')[0] || 'cutout.png';
  const baseName = originalFilename.substring(0, originalFilename.lastIndexOf('.')) || originalFilename;
  
  const exportCanvas = document.createElement('canvas');
  exportCanvas.width = removerCanvas.width;
  exportCanvas.height = removerCanvas.height;
  const exportCtx = exportCanvas.getContext('2d');
  
  if (format === 'jpeg') {
    // Fill background with white since JPEG does not support transparency
    exportCtx.fillStyle = '#ffffff';
    exportCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
  }
  
  exportCtx.drawImage(removerCanvas, 0, 0);
  
  const mimeType = `image/${format}`;
  const dataUrl = exportCanvas.toDataURL(mimeType, 0.95);
  
  chrome.downloads.download({
    url: dataUrl,
    filename: `Rutaabs_downloads/${baseName}_remover.${format}`,
    conflictAction: 'uniquify'
  }, () => {
    alert("Saved cutout image successfully!");
    removerOverlay.classList.remove('open');
  });
};

init();
