function getAllImages() {
  const images = new Map();
  
  // 1. Get all <img> tags
  document.querySelectorAll('img').forEach(img => {
    if (img.src) {
      const url = new URL(img.src, document.baseURI).href;
      images.set(url, {
        url: url,
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height,
        alt: img.alt || ''
      });
    }
  });

  // 2. Get background images from all elements
  document.querySelectorAll('*').forEach(el => {
    const bg = window.getComputedStyle(el).backgroundImage;
    if (bg && bg !== 'none' && bg.startsWith('url(')) {
      const match = bg.match(/url\(["']?([^"']+)["']?\)/);
      if (match) {
        try {
          const url = new URL(match[1], document.baseURI).href;
          if (!images.has(url)) {
            images.set(url, {
              url: url,
              width: el.offsetWidth,
              height: el.offsetHeight,
              alt: 'Background image'
            });
          }
        } catch (e) {}
      }
    }
  });

  // 3. Get <source> tags in <picture>
  document.querySelectorAll('source').forEach(source => {
    if (source.srcset) {
      const firstSrc = source.srcset.split(',')[0].split(' ')[0];
      if (firstSrc) {
        try {
          const url = new URL(firstSrc, document.baseURI).href;
          if (!images.has(url)) {
            images.set(url, {
              url: url,
              width: 0,
              height: 0,
              alt: 'Picture source'
            });
          }
        } catch (e) {}
      }
    }
  });

  return Array.from(images.values());
}

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getImages") {
    sendResponse({ images: getAllImages().map(img => img.url) });
  }
});
