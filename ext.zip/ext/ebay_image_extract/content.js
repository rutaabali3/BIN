'use strict';

(() => {
  function extractListingImages() {
    const imageUrls = new Set();

    // ── Strategy 1: eBay embeds the full image list in a JS variable ──────────
    // Look for the canonical image array eBay injects into inline scripts.
    // These contain ONLY the item's photos (not ads or related items).
    const scriptPatterns = [
      // "maxImageUrl":"https://i.ebayimg.com/images/g/.../s-l1600.jpg"
      /"maxImageUrl"\s*:\s*"(https:\/\/i\.ebayimg\.com\/images\/g\/[^"]+)"/g,
      // "displayImgUrl":"https://..."
      /"displayImgUrl"\s*:\s*"(https:\/\/i\.ebayimg\.com\/images\/g\/[^"]+)"/g,
      // "originalImgUrl":"https://..."
      /"originalImgUrl"\s*:\s*"(https:\/\/i\.ebayimg\.com\/images\/g\/[^"]+)"/g,
      // "imgUrl":"https://..."  — fallback
      /"imgUrl"\s*:\s*"(https:\/\/i\.ebayimg\.com\/images\/g\/[^"]+)"/g,
    ];

    for (const script of document.querySelectorAll('script:not([src])')) {
      const text = script.textContent;
      // Only look in scripts that appear to be the item data blob
      if (!text.includes('maxImageUrl') && !text.includes('displayImgUrl') && !text.includes('originalImgUrl')) continue;

      for (const pattern of scriptPatterns) {
        pattern.lastIndex = 0; // reset regex
        let match;
        while ((match = pattern.exec(text)) !== null) {
          imageUrls.add(toFullRes(match[1]));
        }
      }
    }

    // ── Strategy 2: DOM – main image carousel only ────────────────────────────
    // These containers are specific to the item viewer, not the rest of the page.
    const carouselRoots = [
      document.querySelector('div[data-testid="ux-image-carousel"]'),
      document.querySelector('div.ux-image-carousel'),
      document.querySelector('div#vi_main_img_fs'),
      document.querySelector('div.img-viewer'),
    ].filter(Boolean);

    for (const root of carouselRoots) {
      root.querySelectorAll('img').forEach(img => {
        const src = img.dataset.zoomSrc || img.dataset.src || img.src || '';
        if (src && src.includes('i.ebayimg.com/images/g/')) {
          imageUrls.add(toFullRes(src));
        }
      });

      // data-zoom-src on wrapper elements
      root.querySelectorAll('[data-zoom-src]').forEach(el => {
        imageUrls.add(toFullRes(el.dataset.zoomSrc));
      });
    }

    // ── Strategy 3: filmstrip thumbnails (only inside the carousel area) ──────
    const filmstrip = document.querySelector(
      'div.ux-image-filmstrip, div[data-testid="ux-image-filmstrip"]'
    );
    if (filmstrip) {
      filmstrip.querySelectorAll('img').forEach(img => {
        const src = img.dataset.src || img.src || '';
        if (src && src.includes('i.ebayimg.com/images/g/')) {
          imageUrls.add(toFullRes(src));
        }
      });
    }

    // ── Dedupe and validate ───────────────────────────────────────────────────
    return [...imageUrls].filter(url => {
      try {
        const u = new URL(url);
        // Must be from eBay's image CDN and under the /images/g/ path (item photos)
        return (
          u.hostname === 'i.ebayimg.com' &&
          u.pathname.startsWith('/images/g/')
        );
      } catch {
        return false;
      }
    });
  }

  // Upgrade any size suffix → s-l1600 (full resolution)
  function toFullRes(url = '') {
    return url
      .replace(/\/s-l\d+(\.(?:jpg|jpeg|png|webp|gif))/i, '/s-l1600$1')
      .replace(/\/s-l\d+(?=\?|$)/i, '/s-l1600')
      .split('?')[0]; // strip query strings that force smaller sizes
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'extractImages') {
      const images = extractListingImages();
      sendResponse({ images });
    }
    return true;
  });
})();
