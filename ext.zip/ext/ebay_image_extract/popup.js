'use strict';

// ── Mock Chrome API for Browser Testing ──────────────────────────────────────

if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
  const svg1 = btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <rect width="100%" height="100%" fill="#ffffff" />
    <circle cx="100" cy="100" r="60" fill="#ff5722" />
    <text x="100" y="110" font-family="sans-serif" font-size="14" fill="#ffffff" text-anchor="middle" font-weight="bold">SHOES</text>
  </svg>`);
  const svg2 = btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <rect width="100%" height="100%" fill="#ffffff" />
    <rect x="50" y="50" width="100" height="100" fill="#2196f3" rx="10" />
    <text x="100" y="110" font-family="sans-serif" font-size="14" fill="#ffffff" text-anchor="middle" font-weight="bold">BAG</text>
  </svg>`);
  const svg3 = btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <rect width="100%" height="100%" fill="#ffffff" />
    <polygon points="100,30 170,150 30,150" fill="#4caf50" />
    <text x="100" y="120" font-family="sans-serif" font-size="14" fill="#ffffff" text-anchor="middle" font-weight="bold">CAP</text>
  </svg>`);

  window.chrome = {
    tabs: {
      query: async () => [{ id: 1, url: 'https://www.ebay.co.uk/itm/123456789' }],
      create: (obj) => { window.open(obj.url, '_blank'); },
      sendMessage: (tabId, msg, callback) => {
        if (msg.action === 'extractImages') {
          callback({
            images: [
              `data:image/svg+xml;base64,${svg1}`,
              `data:image/svg+xml;base64,${svg2}`,
              `data:image/svg+xml;base64,${svg3}`
            ]
          });
        }
      }
    },
    scripting: {
      executeScript: async () => [{ result: true }]
    },
    runtime: {
      lastError: null
    }
  };
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function showToast(msg, duration = 3000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function setError(msg) {
  document.getElementById('error-text').textContent = msg;
  showView('view-error');
}

// ── State ────────────────────────────────────────────────────────────────────

let allImages = [];
let selected = new Set();
let activeRemoverIndex = null;
let activeRemoverImage = null; // Store Image element of the currently being edited photo
let activeRemoverColor = '#ffffff';

// ── Selection State UI ────────────────────────────────────────────────────────

function updateSelectionUI() {
  const count = selected.size;
  document.getElementById('sel-count').textContent =
    count > 0 ? `${count} selected` : '';
  
  const total = count > 0 ? count : allImages.length;
  const selectFormat = document.getElementById('select-format').value;
  const formatLabel = selectFormat === 'original' ? 'ZIP' : `${selectFormat.toUpperCase()} ZIP`;
  
  document.getElementById('btn-download').innerHTML = `
    <svg viewBox="0 0 24 24"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/></svg>
    Download ${formatLabel} (${total})
  `;
  
  document.getElementById('btn-select-all').innerHTML =
    selected.size === allImages.length ? `
      <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
      Deselect All
    ` : `
      <svg viewBox="0 0 24 24"><path d="M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17l-4.24-4.24-1.41 1.41 5.66 5.66L23.66 7l-1.42-1.41zM1.41 12.59L0 14l5.66 5.66 1.41-1.41-5.66-5.66z"/></svg>
      Select All
    `;
}

// ── Render Grid ──────────────────────────────────────────────────────────────

function renderGrid(images) {
  allImages = images;
  selected.clear();

  document.getElementById('img-count').textContent = images.length;
  const grid = document.getElementById('image-grid');
  grid.innerHTML = '';

  images.forEach((url, i) => {
    const item = document.createElement('div');
    item.className = 'grid-item';
    item.dataset.index = i;

    const img = document.createElement('img');
    img.src = url;
    img.alt = `Image ${i + 1}`;
    img.loading = 'lazy';

    // Hover actions overlay containing edit / view buttons
    const itemActions = document.createElement('div');
    itemActions.className = 'item-actions';

    const topBar = document.createElement('div');
    topBar.className = 'top-action-bar';

    const checkbox = document.createElement('div');
    checkbox.className = 'item-checkbox';

    const viewBtn = document.createElement('button');
    viewBtn.className = 'action-icon-btn';
    viewBtn.title = 'View Original Image';
    viewBtn.innerHTML = `
      <svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41 9.83-9.83V9h2V3h-6z"/>
      </svg>
    `;

    topBar.appendChild(checkbox);
    topBar.appendChild(viewBtn);

    const editBtn = document.createElement('button');
    editBtn.className = 'center-action-btn';
    editBtn.title = 'Remove Background / Edit';
    editBtn.innerHTML = `
      <svg viewBox="0 0 24 24">
        <path d="M7.5 5.6L10 7 8.6 4.5 10 2 7.5 3.4 5 2l1.4 2.5L5 7zm12 9.8l-2.5-1.4-1.4 2.5 1.4 2.5 2.5-1.4 2.5 1.4-1.4-2.5zm0-9.8L17 7l1.4-2.5L17 2l2.5 1.4L22 2l-1.4 2.5L22 7zM14.1 9.4c.4-.4.4-1 0-1.4l-1.1-1.1c-.4-.4-1-.4-1.4 0l-9.1 9.1v2.5h2.5l9.1-9.1z"/>
      </svg>
      Bg Remover
    `;

    itemActions.appendChild(topBar);
    itemActions.appendChild(editBtn);

    item.appendChild(img);
    item.appendChild(itemActions);

    // Grid Item click toggles selection
    item.addEventListener('click', (e) => {
      // Ignore click if clicking specific buttons
      if (e.target.closest('.action-icon-btn') || e.target.closest('.center-action-btn')) {
        return;
      }
      toggleSelect(i, item);
    });

    viewBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.tabs.create({ url });
    });

    editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openRemoverModal(i, url);
    });

    grid.appendChild(item);
  });

  updateSelectionUI();
  showView('view-results');
}

function toggleSelect(index, el) {
  if (selected.has(index)) {
    selected.delete(index);
    el.classList.remove('selected');
  } else {
    selected.add(index);
    el.classList.add('selected');
  }
  updateSelectionUI();
}

// ── Format Conversion & Fetch Helpers ────────────────────────────────────────

async function getImageAsFormat(url, targetFormat) {
  if (targetFormat === 'original') {
    try {
      const resp = await fetch(url);
      const blob = await resp.blob();
      const ext = (url.match(/\.(jpe?g|png|webp|gif)/i) || ['', 'jpg'])[1].toLowerCase();
      return { blob, ext };
    } catch {
      return { blob: null, ext: null };
    }
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      
      if (targetFormat === 'jpeg') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      ctx.drawImage(img, 0, 0);
      const mimeType = `image/${targetFormat}`;
      canvas.toBlob((blob) => {
        resolve({ blob, ext: targetFormat });
      }, mimeType, 0.95);
    };
    img.onerror = async () => {
      // Fallback
      try {
        const resp = await fetch(url);
        const blob = await resp.blob();
        resolve({ blob, ext: 'jpg' });
      } catch {
        resolve({ blob: null, ext: null });
      }
    };
    img.src = url;
  });
}

// ── ZIP Download ─────────────────────────────────────────────────────────────

function getTargetUrls() {
  if (selected.size > 0) return [...selected].sort((a,b)=>a-b).map(i => allImages[i]);
  return allImages;
}

async function downloadZip() {
  const urls = getTargetUrls();
  if (urls.length === 0) return;

  const btn = document.getElementById('btn-download');
  btn.disabled = true;
  const originalHtml = btn.innerHTML;
  btn.textContent = 'Preparing...';

  try {
    const zip = new JSZip();
    const folder = zip.folder('ebay_images');
    const selectFormat = document.getElementById('select-format').value;

    let done = 0;
    await Promise.all(urls.map(async (url, i) => {
      try {
        const { blob, ext } = await getImageAsFormat(url, selectFormat);
        if (blob) {
          const name = `image_${String(i + 1).padStart(3, '0')}.${ext}`;
          folder.file(name, blob);
        }
      } catch {
        // Skip failed image silently
      }
      done++;
      btn.textContent = `Fetching… ${done}/${urls.length}`;
    }));

    btn.textContent = 'Zipping…';
    const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });

    // Trigger download
    const a = document.createElement('a');
    a.href = URL.createObjectURL(zipBlob);
    a.download = `ebay_listing_images_${selectFormat}.zip`;
    a.click();
    URL.revokeObjectURL(a.href);

    showToast(`✅ Downloaded ${done} image${done !== 1 ? 's' : ''} as ZIP`);
  } catch (err) {
    showToast('❌ ZIP failed: ' + err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = originalHtml;
    updateSelectionUI();
  }
}

function copyUrls() {
  const urls = getTargetUrls();
  navigator.clipboard.writeText(urls.join('\n')).then(() => {
    showToast(`✅ Copied ${urls.length} URL${urls.length !== 1 ? 's' : ''} to clipboard`);
  });
}

// ── Main Extraction ──────────────────────────────────────────────────────────

async function extractImages() {
  showView('view-loading');

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.url || !tab.url.includes('ebay.co.uk')) {
    setError('Please navigate to an eBay.co.uk listing first.');
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
  } catch (_) { /* already injected */ }

  chrome.tabs.sendMessage(tab.id, { action: 'extractImages' }, (response) => {
    if (chrome.runtime.lastError) {
      setError('Could not connect to the page. Try refreshing the tab.');
      return;
    }
    const images = response?.images ?? [];
    if (images.length === 0) {
      showView('view-empty');
    } else {
      renderGrid(images);
    }
  });
}

// ── Background Remover Modal Implementation ─────────────────────────────────

function parseHexColor(hex) {
  const match = hex.match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
  return match ? {
    r: parseInt(match[1], 16),
    g: parseInt(match[2], 16),
    b: parseInt(match[3], 16)
  } : { r: 255, g: 255, b: 255 };
}

function runBackgroundRemoval() {
  if (!activeRemoverImage) return;

  const canvas = document.getElementById('remover-canvas');
  const ctx = canvas.getContext('2d');
  
  const w = activeRemoverImage.naturalWidth || activeRemoverImage.width;
  const h = activeRemoverImage.naturalHeight || activeRemoverImage.height;
  
  canvas.width = w;
  canvas.height = h;
  ctx.drawImage(activeRemoverImage, 0, 0);

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;
  
  const targetColor = parseHexColor(activeRemoverColor);
  const tolerance = parseInt(document.getElementById('remover-tolerance').value, 10);
  
  // Euclidean RGB distance scaling: max distance is sqrt(255^2 * 3) = 441.67
  const threshold = (tolerance / 100) * 441.67;
  // Fade range of 15% of the threshold for anti-aliasing feathering
  const fadeStart = threshold * 0.85;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    
    const dist = Math.sqrt(
      Math.pow(r - targetColor.r, 2) +
      Math.pow(g - targetColor.g, 2) +
      Math.pow(b - targetColor.b, 2)
    );

    if (dist < fadeStart) {
      data[i + 3] = 0; // Fully transparent
    } else if (dist < threshold) {
      // Linear smooth transition
      const ratio = (dist - fadeStart) / (threshold - fadeStart);
      data[i + 3] = Math.round(ratio * 255);
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

function openRemoverModal(index, url) {
  activeRemoverIndex = index;
  activeRemoverImage = new Image();
  activeRemoverImage.crossOrigin = 'anonymous';
  
  activeRemoverImage.onload = () => {
    // Show modal and reset fields
    document.getElementById('remover-modal').classList.add('active');
    
    // Reset inputs
    activeRemoverColor = '#ffffff';
    document.getElementById('remover-color-input').value = '#ffffff';
    document.getElementById('remover-color-hex').textContent = '#ffffff';
    document.getElementById('remover-tolerance').value = '20';
    document.getElementById('remover-tolerance-val').textContent = '20';
    
    runBackgroundRemoval();
  };
  
  activeRemoverImage.onerror = () => {
    showToast('❌ Failed to load image for editing.');
  };
  
  activeRemoverImage.src = url;
}

function closeRemoverModal() {
  document.getElementById('remover-modal').classList.remove('active');
  activeRemoverIndex = null;
  activeRemoverImage = null;
}

// Color picker click on Canvas
document.getElementById('remover-canvas').addEventListener('click', (e) => {
  const canvas = e.target;
  const rect = canvas.getBoundingClientRect();
  
  // Click relative to rendering
  const xPercent = (e.clientX - rect.left) / rect.width;
  const yPercent = (e.clientY - rect.top) / rect.height;
  
  // Real coordinates
  const canvasX = Math.floor(xPercent * canvas.width);
  const canvasY = Math.floor(yPercent * canvas.height);
  
  const ctx = canvas.getContext('2d');
  
  // Temporarily draw clean image to read original color
  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = canvas.width;
  tempCanvas.height = canvas.height;
  const tempCtx = tempCanvas.getContext('2d');
  tempCtx.drawImage(activeRemoverImage, 0, 0);
  
  const pixel = tempCtx.getImageData(canvasX, canvasY, 1, 1).data;
  
  const r = pixel[0].toString(16).padStart(2, '0');
  const g = pixel[1].toString(16).padStart(2, '0');
  const b = pixel[2].toString(16).padStart(2, '0');
  
  const hex = `#${r}${g}${b}`;
  activeRemoverColor = hex;
  document.getElementById('remover-color-input').value = hex;
  document.getElementById('remover-color-hex').textContent = hex;
  
  runBackgroundRemoval();
});

// Manual color input change
document.getElementById('remover-color-input').addEventListener('input', (e) => {
  activeRemoverColor = e.target.value;
  document.getElementById('remover-color-hex').textContent = e.target.value;
  runBackgroundRemoval();
});

// Quick color swatches
document.querySelectorAll('.color-swatch').forEach(swatch => {
  swatch.addEventListener('click', (e) => {
    const hex = e.target.getAttribute('title') === 'White' ? '#ffffff' :
                e.target.getAttribute('title') === 'Black' ? '#000000' : '#ebebeb';
    activeRemoverColor = hex;
    document.getElementById('remover-color-input').value = hex;
    document.getElementById('remover-color-hex').textContent = hex;
    runBackgroundRemoval();
  });
});

// Tolerance slider input
document.getElementById('remover-tolerance').addEventListener('input', (e) => {
  document.getElementById('remover-tolerance-val').textContent = e.target.value;
  runBackgroundRemoval();
});

// Close modal buttons
document.getElementById('btn-modal-close').addEventListener('click', closeRemoverModal);
document.getElementById('btn-remover-cancel').addEventListener('click', closeRemoverModal);

// Apply back to Grid
document.getElementById('btn-remover-apply').addEventListener('click', () => {
  if (activeRemoverIndex === null) return;
  
  const canvas = document.getElementById('remover-canvas');
  const dataUrl = canvas.toDataURL('image/png');
  
  // Update state array
  allImages[activeRemoverIndex] = dataUrl;
  
  // Re-render
  renderGrid(allImages);
  
  closeRemoverModal();
  showToast('✨ Applied transparent cutout to Grid!');
});

// Download Single Edit
document.getElementById('btn-remover-download').addEventListener('click', () => {
  const canvas = document.getElementById('remover-canvas');
  
  // Download as transparent PNG
  canvas.toBlob((blob) => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `ebay_removed_bg_${activeRemoverIndex + 1}.png`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('✅ Downloaded transparent PNG');
  }, 'image/png');
});


// ── Event Listeners ──────────────────────────────────────────────────────────

document.getElementById('btn-extract').addEventListener('click', extractImages);
document.getElementById('btn-retry').addEventListener('click', extractImages);

document.getElementById('btn-select-all').addEventListener('click', () => {
  const items = document.querySelectorAll('.grid-item');
  if (selected.size === allImages.length) {
    selected.clear();
    items.forEach(el => el.classList.remove('selected'));
  } else {
    allImages.forEach((_, i) => selected.add(i));
    items.forEach(el => el.classList.add('selected'));
  }
  updateSelectionUI();
});

document.getElementById('btn-copy').addEventListener('click', copyUrls);
document.getElementById('btn-download').addEventListener('click', downloadZip);

// Format selector change
document.getElementById('select-format').addEventListener('change', () => {
  updateSelectionUI();
});
