'use strict';

(() => {
  // Helpers to upgrade Amazon image sizes/formats to maximum possible resolution
  function toFullRes(url = '') {
    if (!url) return '';
    // Amazon URLs often look like: https://images-na.ssl-images-amazon.com/images/I/71xyz._AC_SL1500_.jpg
    // Suffixes usually lie between the last dot and the file extension.
    // E.g., ._AC_SL1500_ or ._SY300_ or ._SX300_ or ._UL1500_ or ._SS160_
    // Removing the segment starting with `._` up to the last `.jpg` (or webp, png, etc.)
    // gives the original ultra-high resolution uncompressed image.
    
    // We match any substring starting with ._ and ending with any parameters before the file extension
    // E.g., "71xyz._AC_SL1500_.jpg" -> "71xyz.jpg"
    return url
      .replace(/\._[A-Z0-9_-]+_(?=\.[a-z]+)/i, '') // standard suffix block
      .replace(/\._[A-Z0-9_-]+_(?=\.[A-Z0-9_-]+_(?=\.[a-z]+))/i, '') // double suffix block
      .split('?')[0]; // strip query parameters
  }

  function extractListingImages() {
    const imageUrls = new Set();

    // ── Strategy 1: Search for script contents with 'colorImages' or 'imageGalleryData' ──
    const scripts = document.querySelectorAll('script:not([src])');
    for (const script of scripts) {
      const text = script.textContent;
      if (!text) continue;

      // Scan 'colorImages'
      // Expected structure: 'colorImages': { 'initial': [ { "hiRes": "url", "large": "url", ... } ] }
      if (text.includes('colorImages') || text.includes('ImageBlockATF')) {
        const colorImagesRegex = /['"]colorImages['"]\s*:\s*({\s*['"]initial['"]\s*:\s*\[[\s\S]+?\]\s*})/g;
        let match;
        while ((match = colorImagesRegex.exec(text)) !== null) {
          try {
            // Safe JSON parse by parsing the matched segment
            // We need to clean keys if they are not quoted (e.g. key: val -> "key": val)
            const objStr = match[1]
              .replace(/(['"])?([a-zA-Z0-9_]+)(['"])?\s*:/g, '"$2":')
              .replace(/'/g, '"');
            const data = JSON.parse(objStr);
            const list = data.initial || [];
            list.forEach(item => {
              if (item.hiRes) imageUrls.add(toFullRes(item.hiRes));
              else if (item.large) imageUrls.add(toFullRes(item.large));
              else if (item.mainUrl) imageUrls.add(toFullRes(item.mainUrl));
            });
          } catch (e) {
            // Fallback: simple regex findall
            const hiResMatches = text.match(/"hiRes"\s*:\s*"([^"]+)"/g);
            if (hiResMatches) {
              hiResMatches.forEach(m => {
                const urlMatch = m.match(/"hiRes"\s*:\s*"([^"]+)"/);
                if (urlMatch) imageUrls.add(toFullRes(urlMatch[1]));
              });
            }
          }
        }
      }

      // Scan 'imageGalleryData'
      if (text.includes('imageGalleryData')) {
        const galleryRegex = /['"]imageGalleryData['"]\s*:\s*(\[[\s\S]+?\])/g;
        let match;
        while ((match = galleryRegex.exec(text)) !== null) {
          try {
            const objStr = match[1]
              .replace(/(['"])?([a-zA-Z0-9_]+)(['"])?\s*:/g, '"$2":')
              .replace(/'/g, '"');
            const list = JSON.parse(objStr);
            list.forEach(item => {
              if (item.mainUrl) imageUrls.add(toFullRes(item.mainUrl));
            });
          } catch (e) {
            // do nothing, fallback to regex search
          }
        }
      }
    }

    // ── Strategy 2: Extract Main Product Image Elements from DOM ──
    // e.g. #landingImage, #imgBlkFront, #main-image, etc.
    const mainImages = [
      document.querySelector('#landingImage'),
      document.querySelector('#imgBlkFront'),
      document.querySelector('#main-image'),
      document.querySelector('.imgTagWrapper img'),
      document.querySelector('#ebooksImgBlkFront')
    ].filter(Boolean);

    mainImages.forEach(img => {
      // Sometimes high-res is in data-old-hires or data-a-dynamic-image
      if (img.dataset.oldHires) {
        imageUrls.add(toFullRes(img.dataset.oldHires));
      }
      if (img.dataset.aDynamicImage) {
        try {
          // data-a-dynamic-image is a JSON object string like: {"url1":[width, height], "url2":[width, height]}
          const dyn = JSON.parse(img.dataset.aDynamicImage);
          Object.keys(dyn).forEach(url => imageUrls.add(toFullRes(url)));
        } catch (e) {}
      }
      if (img.src) {
        imageUrls.add(toFullRes(img.src));
      }
    });

    // ── Strategy 3: Thumbnails/Filmstrips in Gallery ──
    const thumbnails = document.querySelectorAll('#altImages ul li.imageThumbnail img, #altImages ul li.imageThumbnail input[type="button"] img, #altImages img');
    thumbnails.forEach(thumb => {
      const src = thumb.src || '';
      if (src) {
        imageUrls.add(toFullRes(src));
      }
    });

    // ── Strategy 4: Fallback to all images from m.media-amazon.com/images/I/ or images-na.ssl-images-amazon.com ──
    const allImgs = document.querySelectorAll('img');
    allImgs.forEach(img => {
      const src = img.src || '';
      if (src && (src.includes('media-amazon.com/images/I/') || src.includes('ssl-images-amazon.com/images/I/'))) {
        // Skip small layout icons or utility elements (e.g., ratings stars, checkmarks, brands) if recognizable
        if (src.includes('/ext/') || src.includes('/sprite/') || src.includes('play-button') || src.includes('video-thumbnail')) {
          return;
        }
        imageUrls.add(toFullRes(src));
      }
    });

    // Deduplicate and filter out invalid/empty strings
    return Array.from(imageUrls).filter(url => {
      try {
        const u = new URL(url);
        return (
          (u.hostname.includes('media-amazon.com') || u.hostname.includes('ssl-images-amazon.com')) &&
          u.pathname.includes('/images/I/')
        );
      } catch {
        return false;
      }
    });
  }

  // Listener for connection
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'extractImages') {
      const images = extractListingImages();
      sendResponse({ images });
    }
    return true;
  });
})();
