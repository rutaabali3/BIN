'use strict';

// ── UI Control Helpers ────────────────────────────────────────────────────────

function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function showToast(msg, duration = 2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function setError(msg) {
  document.getElementById('error-text').textContent = msg;
  showView('view-error');
}

// ── Extension State ──────────────────────────────────────────────────────────

let allImages = [];
let selected = new Set();
let currentBgRemoverUrl = '';
let activeBgColorMode = 'white'; // 'white' or 'auto'

// ── Update Selection UI Info ─────────────────────────────────────────────────

function updateSelectionUI() {
  const count = selected.size;
  document.getElementById('sel-count').textContent =
    count > 0 ? `${count} selected` : '';
  const total = count > 0 ? count : allImages.length;
  
  const formatRadio = document.querySelector('input[name="ext-format"]:checked');
  const fmtLabel = formatRadio ? formatRadio.value.toUpperCase() : 'ORIGINAL';
  document.getElementById('btn-download').textContent =
    `Download ZIP (${total} in ${fmtLabel})`;
    
  document.getElementById('btn-select-all').textContent =
    selected.size === allImages.length ? 'Deselect all' : 'Select all';
}

// ── Render Results Image Grid ────────────────────────────────────────────────

function renderGrid(images) {
  allImages = images;
  selected.clear();

  document.getElementById('img-count').textContent = images.length;
  const grid = document.getElementById('image-grid');
  grid.innerHTML = '';

  images.forEach((url, i) => {
    const item = document.createElement('div');
    item.className = 'grid-item';
    item.dataset.index = i;

    const img = document.createElement('img');
    img.src = url;
    img.alt = `Amazon Image ${i + 1}`;
    img.loading = 'lazy';

    // ── Badge 1: Magic Wand for Local BG removal tool ──
    const wand = document.createElement('div');
    wand.className = 'card-badge badge-bg-remover';
    wand.title = 'Remove Background Color';
    wand.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
        <path d="M7.5 5.6L10 7 8.6 4.5 10 2 7.5 3.4 5 2l1.4 2.5L5 7zm12 9.8l-2.5-1.4-1.4 2.5 1.4 2.5 2.5-1.4 2.5 1.4-1.4-2.5 1.4-2.5zm0-10.8l-1.4 2.5L15 6l2.5 1.4L18.9 10 20.3 7.5 22.8 6l-2.5-1.4zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM16.24 4.34c.39-.39 1.02-.39 1.41 0l2.01 2.01c.39.39.39 1.02 0 1.41l-1.57 1.57-3.75-3.75 1.9-1.24z"/>
      </svg>
    `;

    // ── Badge 2: Open External / Original Size ──
    const ext = document.createElement('div');
    ext.className = 'card-badge badge-external';
    ext.title = 'Open High-Resolution Original';
    ext.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/>
      </svg>
    `;

    // ── Badge 3: Grid Selection Checkmark ──
    const check = document.createElement('div');
    check.className = 'card-badge badge-checkmark';
    check.innerHTML = '✓';

    item.appendChild(img);
    item.appendChild(wand);
    item.appendChild(ext);
    item.appendChild(check);

    // Grid selection toggle
    item.addEventListener('click', () => toggleSelect(i, item));

    // Handle background remover opening
    wand.addEventListener('click', (e) => {
      e.stopPropagation();
      openBgRemover(url);
    });

    // Handle opening high-res link in a new tab
    ext.addEventListener('click', (e) => {
      e.stopPropagation();
      if (typeof chrome !== 'undefined' && chrome.tabs) {
        chrome.tabs.create({ url });
      } else {
        window.open(url, '_blank');
      }
    });

    grid.appendChild(item);
  });

  updateSelectionUI();
  showView('view-results');
}

function toggleSelect(index, el) {
  if (selected.has(index)) {
    selected.delete(index);
    el.classList.remove('selected');
  } else {
    selected.add(index);
    el.classList.add('selected');
  }
  updateSelectionUI();
}

// ── On-the-fly Image Extension Conversion & Processing ───────────────────────

/**
 * Loads an image from URL and converts it to a different file format (JPEG, PNG, WebP) dynamically via Canvas.
 * Handles potential CORS limitations gracefully.
 */
async function convertImageFormat(url, targetFormat) {
  if (targetFormat === 'original') {
    const response = await fetch(url);
    const blob = await response.blob();
    const filename = url.substring(url.lastIndexOf('/') + 1).split('?')[0] || 'image.jpg';
    return { blob, filename };
  }

  return new Promise((resolve, reject) => {
    const img = new Image();
    if (url.startsWith('http://') || url.startsWith('https://')) {
      img.crossOrigin = 'Anonymous';
    }
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);

      let mimeType = 'image/png';
      let ext = 'png';
      if (targetFormat === 'webp') {
        mimeType = 'image/webp';
        ext = 'webp';
      } else if (targetFormat === 'jpeg') {
        mimeType = 'image/jpeg';
        ext = 'jpg';
      }

      canvas.toBlob((blob) => {
        if (blob) {
          // Construct fresh filename
          const originalName = url.substring(url.lastIndexOf('/') + 1).split('?')[0] || 'image';
          const baseName = originalName.substring(0, originalName.lastIndexOf('.')) || originalName;
          resolve({ blob, filename: `${baseName}.${ext}` });
        } else {
          reject(new Error('Canvas conversion resulted in empty blob'));
        }
      }, mimeType, 0.92);
    };
    img.onerror = () => {
      reject(new Error('Failed to load image for format conversion'));
    };
    img.src = url;
  });
}

// ── ZIP Generator with Parallel Download & Format Mapping ────────────────────

function getTargetUrls() {
  if (selected.size > 0) return [...selected].sort((a,b)=>a-b).map(i => allImages[i]);
  return allImages;
}

async function downloadZip() {
  const urls = getTargetUrls();
  if (urls.length === 0) return;

  const btn = document.getElementById('btn-download');
  const formatRadio = document.querySelector('input[name="ext-format"]:checked');
  const targetFormat = formatRadio ? formatRadio.value : 'original';

  btn.disabled = true;
  btn.textContent = 'Analyzing…';

  try {
    const zip = new JSZip();
    const folder = zip.folder('amazon_hd_images');

    let done = 0;
    await Promise.all(urls.map(async (url, i) => {
      try {
        const { blob, filename } = await convertImageFormat(url, targetFormat);
        // Prefix with clean index sequence
        const numberedName = `${String(i + 1).padStart(3, '0')}_${filename}`;
        folder.file(numberedName, blob);
      } catch (err) {
        // Fallback: try direct fetch if canvas conversion failed due to CORS issues
        try {
          const resp = await fetch(url);
          const rawBlob = await resp.blob();
          const ext = (url.match(/\.(jpe?g|png|webp|gif)/i) || ['','jpg'])[1].toLowerCase();
          const backupName = `${String(i + 1).padStart(3, '0')}_image.${ext}`;
          folder.file(backupName, rawBlob);
        } catch {
          // Skip silently on ultimate network failure
        }
      }
      done++;
      btn.textContent = `Fetching… ${done}/${urls.length}`;
    }));

    btn.textContent = 'Archiving…';
    const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });

    // Trigger instant download
    const a = document.createElement('a');
    a.href = URL.createObjectURL(zipBlob);
    a.download = `amazon_listing_images_${targetFormat}.zip`;
    a.click();
    URL.revokeObjectURL(a.href);

    showToast(`✅ Downloaded ${done} assets successfully!`);
  } catch (err) {
    showToast('❌ Failed to compile ZIP: ' + err.message);
  } finally {
    btn.disabled = false;
    updateSelectionUI();
  }
}

function copyUrls() {
  const urls = getTargetUrls();
  navigator.clipboard.writeText(urls.join('\n')).then(() => {
    showToast(`Copied ${urls.length} link${urls.length !== 1 ? 's' : ''} to clipboard!`);
  });
}

// ── Interactive Local Background Remover chroma-keying ───────────────────────

const modal = document.getElementById('bg-remover-modal');
const bgRemOrig = document.getElementById('bg-rem-orig');
const bgRemCanvas = document.getElementById('bg-rem-canvas');
const sliderTolerance = document.getElementById('slider-tolerance');
const sliderFeather = document.getElementById('slider-feather');
const valTolerance = document.getElementById('val-tolerance');
const valFeather = document.getElementById('val-feather');

let loadedImageElement = null;

function openBgRemover(url) {
  currentBgRemoverUrl = url;
  modal.classList.add('active');
  bgRemOrig.src = url;

  // Render on loaded
  const img = new Image();
  if (url.startsWith('http://') || url.startsWith('https://')) {
    img.crossOrigin = 'Anonymous';
  }
  img.onload = () => {
    loadedImageElement = img;
    applyBackgroundRemoval();
  };
  img.src = url;
}

function closeBgRemover() {
  modal.classList.remove('active');
  loadedImageElement = null;
}

// Chroma Key / White Space background removal local canvas algorithm
function applyBackgroundRemoval() {
  if (!loadedImageElement) return;

  const canvas = bgRemCanvas;
  const ctx = canvas.getContext('2d');

  // Constrain render size for fast interactive preview feedback, but maintain high aspect ratio
  const maxDim = 400;
  let w = loadedImageElement.naturalWidth;
  let h = loadedImageElement.naturalHeight;
  if (w > maxDim || h > maxDim) {
    if (w > h) {
      h = Math.round((h * maxDim) / w);
      w = maxDim;
    } else {
      w = Math.round((w * maxDim) / h);
      h = maxDim;
    }
  }

  canvas.width = w;
  canvas.height = h;

  // Draw original
  ctx.drawImage(loadedImageElement, 0, 0, w, h);

  const tolerance = parseInt(sliderTolerance.value);
  const feather = parseInt(sliderFeather.value);

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Determine target background color
  let targetR = 255;
  let targetG = 255;
  let targetB = 255;

  if (activeBgColorMode === 'auto') {
    // Read average of top-left and top-right pixels
    const tlIdx = 0;
    const trIdx = (w - 1) * 4;
    targetR = Math.round((data[tlIdx] + data[trIdx]) / 2);
    targetG = Math.round((data[tlIdx + 1] + data[trIdx + 1]) / 2);
    targetB = Math.round((data[tlIdx + 2] + data[trIdx + 2]) / 2);
  }

  // Process pixel manipulation arrays
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Compute Euclidean distance in 3D color space
    const dist = Math.sqrt(
      (r - targetR) ** 2 +
      (g - targetG) ** 2 +
      (b - targetB) ** 2
    );

    if (dist < tolerance) {
      // Transition boundary with feathering softness
      if (feather > 0 && dist > (tolerance - feather)) {
        const ratio = (dist - (tolerance - feather)) / feather;
        data[i + 3] = Math.round(ratio * 255);
      } else {
        data[i + 3] = 0; // complete transparency
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

// Download final transparent artwork at full high-resolution
async function downloadTransparentHQ() {
  if (!loadedImageElement) return;

  const canvas = document.createElement('canvas');
  const w = loadedImageElement.naturalWidth;
  const h = loadedImageElement.naturalHeight;
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');
  ctx.drawImage(loadedImageElement, 0, 0);

  const tolerance = parseInt(sliderTolerance.value);
  const feather = parseInt(sliderFeather.value);

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  let targetR = 255;
  let targetG = 255;
  let targetB = 255;

  if (activeBgColorMode === 'auto') {
    const tlIdx = 0;
    const trIdx = (w - 1) * 4;
    targetR = Math.round((data[tlIdx] + data[trIdx]) / 2);
    targetG = Math.round((data[tlIdx + 1] + data[trIdx + 1]) / 2);
    targetB = Math.round((data[tlIdx + 2] + data[trIdx + 2]) / 2);
  }

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const dist = Math.sqrt(
      (r - targetR) ** 2 +
      (g - targetG) ** 2 +
      (b - targetB) ** 2
    );

    if (dist < tolerance) {
      if (feather > 0 && dist > (tolerance - feather)) {
        const ratio = (dist - (tolerance - feather)) / feather;
        data[i + 3] = Math.round(ratio * 255);
      } else {
        data[i + 3] = 0;
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  canvas.toBlob((blob) => {
    if (blob) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      const originalName = currentBgRemoverUrl.substring(currentBgRemoverUrl.lastIndexOf('/') + 1).split('?')[0] || 'image';
      const baseName = originalName.substring(0, originalName.lastIndexOf('.')) || originalName;
      a.download = `${baseName}_transparent.png`;
      a.click();
      URL.revokeObjectURL(a.href);
      showToast('✅ Downloaded transparent PNG!');
      closeBgRemover();
    } else {
      showToast('❌ Failed to process high-res background removal');
    }
  }, 'image/png');
}

// ── Main Extraction & Message Dispatching ────────────────────────────────────

async function runExtraction() {
  showView('view-loading');

  // Verify Tab Context
  if (typeof chrome === 'undefined' || !chrome.tabs) {
    // Local / Playwright mockup testing sandbox fallback
    setTimeout(() => {
      const dummyImages = [
        'icons/icon128.png',
        'icons/icon48.png',
        'icons/icon128.png',
        'icons/icon48.png'
      ];
      renderGrid(dummyImages);
    }, 1200);
    return;
  }

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.url || (!tab.url.includes('amazon.') && !tab.url.includes('amzn.'))) {
      setError('Please navigate to an Amazon listing product detail page first.');
      return;
    }

    // Attempt injection of Content Script dynamically if not automatically registered
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
    } catch (e) {
      /* Injected already */
    }

    // Message connection
    chrome.tabs.sendMessage(tab.id, { action: 'extractImages' }, (response) => {
      if (chrome.runtime.lastError) {
        setError('Connection lost. Please refresh your Amazon tab and try scanning again.');
        return;
      }
      const images = response?.images ?? [];
      if (images.length === 0) {
        showView('view-empty');
      } else {
        renderGrid(images);
      }
    });

  } catch (err) {
    setError('Failed to query Amazon active tab: ' + err.message);
  }
}

// ── Event Handlers Setup ─────────────────────────────────────────────────────

document.getElementById('btn-extract').addEventListener('click', runExtraction);
document.getElementById('btn-retry').addEventListener('click', runExtraction);

// Select All Toggle
document.getElementById('btn-select-all').addEventListener('click', () => {
  const items = document.querySelectorAll('.grid-item');
  if (selected.size === allImages.length) {
    selected.clear();
    items.forEach(el => el.classList.remove('selected'));
  } else {
    allImages.forEach((_, i) => selected.add(i));
    items.forEach(el => el.classList.add('selected'));
  }
  updateSelectionUI();
});

// Format options interactive updates
document.querySelectorAll('input[name="ext-format"]').forEach(radio => {
  radio.addEventListener('change', updateSelectionUI);
});

// ZIP & links trigger
document.getElementById('btn-copy').addEventListener('click', copyUrls);
document.getElementById('btn-download').addEventListener('click', downloadZip);

// Background Remover settings change handlers
sliderTolerance.addEventListener('input', () => {
  valTolerance.textContent = sliderTolerance.value;
  applyBackgroundRemoval();
});

sliderFeather.addEventListener('input', () => {
  valFeather.textContent = sliderFeather.value;
  applyBackgroundRemoval();
});

document.getElementById('btn-col-white').addEventListener('click', (e) => {
  document.getElementById('btn-col-white').classList.add('active');
  document.getElementById('btn-col-auto').classList.remove('active');
  activeBgColorMode = 'white';
  applyBackgroundRemoval();
});

document.getElementById('btn-col-auto').addEventListener('click', (e) => {
  document.getElementById('btn-col-auto').classList.add('active');
  document.getElementById('btn-col-white').classList.remove('active');
  activeBgColorMode = 'auto';
  applyBackgroundRemoval();
});

// Modal Actions
document.getElementById('btn-close-modal').addEventListener('click', closeBgRemover);
document.getElementById('btn-cancel-modal').addEventListener('click', closeBgRemover);
document.getElementById('btn-save-transparent').addEventListener('click', downloadTransparentHQ);

// Initial Auto-run on popup startup
document.addEventListener('DOMContentLoaded', () => {
  runExtraction();
});
