// content.js — runs in the ISOLATED world on Instagram post/reel pages.
// Finds every image/video in the CURRENTLY VIEWED post only (never the
// recommended posts below), and accumulates lazy-loaded carousel slides.

(() => {
  if (window.__instaContentInstalled) return;
  window.__instaContentInstalled = true;

  // Data captured by the MAIN-world interceptor (best source: full carousel list)
  let intercepted = null;

  document.addEventListener('__instaScrapeData', (ev) => {
    try { intercepted = JSON.parse(JSON.stringify(ev.detail)); } catch (e) { /* ignore */ }
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'INSTA_SCAN') return;
    scan().then(sendResponse).catch((e) => sendResponse({ error: String(e && e.message || e) }));
    return true; // async
  });

  function shortcode() {
    const m = location.pathname.match(/\/(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/);
    return m ? m[2] : null;
  }

  // ------------------------------------------------------------------ //
  // URL helpers
  // ------------------------------------------------------------------ //
  function cleanUrl(u) {
    try { const x = new URL(u); x.hash = ''; return x.toString(); }
    catch (e) { return u; }
  }
  function isMediaHost(u) { return /(cdninstagram\.com|fbcdn\.net|fbsbx\.com)/i.test(u); }
  function mediaId(u) {
    try {
      const x = new URL(u);
      return x.pathname.replace(/\/[sp]\d+x\d+\//, '/SIZE/');
    } catch (e) { return u; }
  }
  function parseSrcset(srcset) {
    const out = [];
    (srcset || '').split(',').forEach((part) => {
      const m = part.trim().match(/^(\S+)\s+(\d+)w/);
      if (m) out.push({ url: cleanUrl(m[1]), w: parseInt(m[2], 10) });
    });
    return out;
  }

  // ------------------------------------------------------------------ //
  // Locate the post being viewed (NOT the recommendations below)
  // ------------------------------------------------------------------ //
  function findPostRoot() {
    // modal / overlay view
    const dialog = document.querySelector('div[role="dialog"]');
    if (dialog) {
      const a = dialog.querySelector('article');
      if (a) return a;
    }
    // direct post page: first article in <main> that looks like a post
    const main = document.querySelector('main');
    if (main) {
      const arts = main.querySelectorAll('article');
      for (const a of arts) {
        if (a.querySelector('header a[href^="/"]') || a.querySelector('time')) return a;
      }
      if (arts.length) return arts[0];
    }
    return null;
  }

  function isInPost(el) {
    const root = findPostRoot();
    return !!(root && (root === el || root.contains(el)));
  }

  // ------------------------------------------------------------------ //
  // Accumulate media as slides load (carousels unload off-screen slides)
  // ------------------------------------------------------------------ //
  const observed = new Map();  // mediaId -> { type, url }
  const liToId = new Map();    // <li> element -> mediaId (dedupe img/video of same slide)
  let observedSC = null;

  function noteMedia(el) {
    const sc = shortcode();
    if (sc !== observedSC) { observed.clear(); liToId.clear(); observedSC = sc; }

    if (!isInPost(el)) return;
    if (el.closest && el.closest('header')) return;      // author avatar
    if ((el.getAttribute && (el.getAttribute('alt') || '').toLowerCase().includes('profile picture'))) return;

    let type, url;
    if (el.tagName === 'VIDEO') {
      type = 'video';
      url = el.currentSrc || el.src || (el.querySelector('source') || {}).src || '';
    } else {
      type = 'image';
      url = el.currentSrc || el.src || '';
      let w = el.naturalWidth || 0;
      if (el.srcset) {
        const cands = parseSrcset(el.srcset).sort((a, b) => b.w - a.w);
        if (cands.length) { url = cands[0].url; w = cands[0].w; }
      }
      if (w && w < 250) return;                          // avatar-sized thumbnail
    }

    if (!url || !/^https:/i.test(url) || !isMediaHost(url)) return;
    const key = mediaId(url);
    const clean = cleanUrl(url);

    // dedupe: a slide's <img> poster vs its <video>
    const li = el.closest && el.closest('li');
    if (li) {
      const prevId = liToId.get(li);
      if (prevId && observed.has(prevId)) {
        const prev = observed.get(prevId);
        if (prev.type === 'video') return;               // already have the real video
        if (prev.type === 'image' && type === 'video') observed.delete(prevId);
      }
      liToId.set(li, key);
    }
    if (!observed.has(key)) observed.set(key, { type, url: clean });
  }

  const mo = new MutationObserver((muts) => {
    for (const mut of muts) {
      for (const n of mut.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.tagName === 'IMG' || n.tagName === 'VIDEO') noteMedia(n);
        else if (n.querySelectorAll) n.querySelectorAll('img, video').forEach(noteMedia);
      }
    }
  });
  try { mo.observe(document.documentElement, { childList: true, subtree: true }); }
  catch (e) { /* ignore */ }

  // ------------------------------------------------------------------ //
  // Scan
  // ------------------------------------------------------------------ //
  function requestIntercepted() {
    return new Promise((resolve) => {
      const id = Math.random().toString(36).slice(2);
      const handler = (ev) => {
        if (ev.detail && ev.detail.id === id) {
          document.removeEventListener('__instaScrapeReply', handler);
          if (ev.detail.data) intercepted = ev.detail.data;
          resolve();
        }
      };
      document.addEventListener('__instaScrapeReply', handler);
      document.dispatchEvent(new CustomEvent('__instaScrapeRequest', { detail: { id } }));
      setTimeout(() => { document.removeEventListener('__instaScrapeReply', handler); resolve(); }, 400);
    });
  }

  function dedupe(items) {
    const seen = new Set();
    return items.filter((it) => {
      const k = mediaId(it.url);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  function domAuthor() {
    const root = findPostRoot();
    const a = root && root.querySelector('header a[href^="/"]');
    return a ? a.textContent.trim() : '';
  }

  async function scan() {
    const sc = shortcode();
    if (!sc) throw new Error('Open a post page first (URL should contain /p/<code>/).');

    // 1) full manifest from the interceptor (all carousel items)
    await requestIntercepted();
    if (intercepted && intercepted.shortcode === sc && intercepted.items && intercepted.items.length) {
      return {
        shortcode: sc,
        author: intercepted.author || '',
        caption: intercepted.caption || '',
        timestamp: intercepted.timestamp || null,
        items: dedupe(intercepted.items),
        source: 'api',
      };
    }

    // 2) fallback: media we have actually seen in the post (post-scoped only)
    const root = findPostRoot();
    if (root) root.querySelectorAll('img, video').forEach(noteMedia);
    const items = Array.from(observed.values());
    if (!items.length) {
      throw new Error(
        'No media found. If this is a private post, make sure you are logged in ' +
        'and follow the account. Otherwise refresh the page and try again.'
      );
    }
    return { shortcode: sc, author: domAuthor(), caption: '', timestamp: null, items, source: 'dom' };
  }
})();
