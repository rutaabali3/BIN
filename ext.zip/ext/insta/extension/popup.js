// popup.js — orchestrates scan + download of the post as a ZIP.
'use strict';

const $ = (id) => document.getElementById(id);
let current = null; // { shortcode, author, caption, timestamp, items, source }

const ITEM_TIMEOUT_MS = 60000; // per-media fetch timeout

init();

async function init() {
  $('scan').addEventListener('click', onScan);
  $('save').addEventListener('click', onSave);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/instagram\.com\/(p|reel|reels|tv)\//.test(tab.url || '')) {
      setStatus('Open an Instagram post / reel / carousel page, then click Scan.', 'err');
      $('scan').disabled = true;
      $('save').disabled = true;
      return;
    }
    window.__tab = tab;
  } catch (e) {
    setStatus('Could not read the active tab.', 'err');
  }
}

async function onScan() {
  const tab = window.__tab;
  if (!tab) return;
  $('scan').disabled = true;
  $('save').disabled = true;
  setStatus('Scanning post…');
  setProgress('');

  try {
    let res;
    try {
      res = await chrome.tabs.sendMessage(tab.id, { type: 'INSTA_SCAN' });
    } catch (e) {
      // content script not injected (page loaded before install) — inject now
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      res = await chrome.tabs.sendMessage(tab.id, { type: 'INSTA_SCAN' });
    }
    if (res && res.error) throw new Error(res.error);
    if (!res || !res.items || !res.items.length) throw new Error('No media found on this page.');

    current = res;
    $('shortcode').textContent = res.shortcode || '—';
    $('author').textContent = (res.author || '—').slice(0, 40);
    $('count').textContent = `${res.items.length} (${summarize(res.items)})`;
    $('save').disabled = false;

    if (res.source === 'api') {
      setStatus(`Found ${res.items.length} item(s). Click "Download ZIP".`);
      setProgress('full media list captured');
    } else {
      setStatus(`Found ${res.items.length} item(s) so far. Click "Download ZIP" when done swiping.`, 'err');
      setProgress(`partial: swipe through every slide of the carousel, then re-scan to add the rest`);
    }
  } catch (e) {
    setStatus('Scan failed: ' + (e.message || e), 'err');
    setProgress('');
  } finally {
    $('scan').disabled = false;
  }
}

function summarize(items) {
  const v = items.filter((i) => i.type === 'video').length;
  const p = items.filter((i) => i.type === 'image').length;
  return [v ? `${v} video` : '', p ? `${p} image` : ''].filter(Boolean).join(' + ');
}

async function onSave() {
  $('save').disabled = true;
  try {
    if (!current) {
      setStatus('No scan yet — scanning first…');
      await onScan();
      if (!current) { $('save').disabled = false; return; }
    }
    await runDownload();
  } catch (e) {
    setStatus('Download failed: ' + (e && e.message || e), 'err');
    setProgress('');
  } finally {
    $('save').disabled = false;
  }
}

async function runDownload() {
  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip not loaded — reload the extension (chrome://extensions → ↻) and try again.');
  }
  const items = current.items;
  const sc = current.shortcode || 'post';

  const meta = {
    source_url: 'https://www.instagram.com/p/' + sc + '/',
    shortcode: sc,
    author: current.author || '',
    caption: current.caption || '',
    timestamp: current.timestamp || null,
    scraped_at: new Date().toISOString(),
    item_count: items.length,
    items: [],
  };

  const zip = new JSZip();
  let okCount = 0;
  let totalBytes = 0;

  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    setProgress(`Downloading ${i + 1}/${items.length} (${it.type})…`);
    try {
      const r = await fetchItem(it.url);
      const buf = await r.arrayBuffer();
      const ext = fileExt(it.type, r.headers.get('content-type'));
      const name = `${String(i + 1).padStart(2, '0')}_${it.type}.${ext}`;
      zip.file(name, buf);
      meta.items.push({ index: i + 1, type: it.type, url: it.url, file: name, size_bytes: buf.byteLength });
      okCount++;
      totalBytes += buf.byteLength;
    } catch (e) {
      meta.items.push({ index: i + 1, type: it.type, url: it.url, error: String(e && e.message || e) });
    }
  }

  if (!okCount) {
    setStatus('Could not download any media. Refresh the post page and try again.', 'err');
    setProgress('');
    return;
  }

  setProgress('Building ZIP…');
  zip.file('metadata.json', JSON.stringify(meta, null, 2));
  const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });

  setProgress('Saving…');
  triggerDownload(blob, `insta_${sc}.zip`);

  const extra = okCount < items.length ? ` (${items.length - okCount} failed — see metadata.json)` : '';
  setStatus(`Saved ${okCount}/${items.length} item(s) → insta_${sc}.zip (${human(totalBytes)})${extra}`, 'ok');
  setProgress('Check your browser Downloads folder.');
}

// ------------------------------------------------------------------ //
// helpers
// ------------------------------------------------------------------ //
async function fetchItem(url) {
  let lastErr;
  for (const credentials of ['omit', 'include']) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), ITEM_TIMEOUT_MS);
    try {
      const r = await fetch(url, { credentials, signal: ctrl.signal });
      if (r.ok) return r;
      lastErr = new Error('HTTP ' + r.status);
    } catch (e) {
      lastErr = e;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastErr || new Error('fetch failed');
}

function fileExt(type, contentType) {
  if (type === 'video') return 'mp4';
  const ct = (contentType || '').toLowerCase();
  if (ct.includes('webp')) return 'webp';
  if (ct.includes('png')) return 'png';
  if (ct.includes('gif')) return 'gif';
  if (ct.includes('heic') || ct.includes('heif')) return 'heic';
  return 'jpg';
}

// Download without opening a native "Save As" dialog. Using a dialog here is
// what breaks downloads: the dialog steals focus, the popup closes, and the
// blob URL is invalidated before the download starts.
function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 120000);
}

function human(nbytes) {
  let n = Number(nbytes || 0);
  for (const unit of ['B', 'KB', 'MB', 'GB']) {
    if (n < 1024 || unit === 'GB') return unit === 'B' ? `${n} B` : `${n.toFixed(1)} ${unit}`;
    n /= 1024;
  }
}

function setStatus(text, cls) {
  const el = $('status');
  el.textContent = text;
  el.className = cls || '';
}

function setProgress(text) {
  $('progress').textContent = text || '';
}
