// interceptor.js — runs in the MAIN world at document_start.
// Wraps fetch / XHR / Response.json to capture Instagram's own API responses,
// then extracts the FULL media manifest (every carousel item, real URLs).
(function () {
  'use strict';
  if (window.__instaInterceptorInstalled) return;
  window.__instaInterceptorInstalled = true;

  const store = { media: null, lastSC: null };

  // ---------------------------------------------------------------- helpers
  function cleanUrl(u) {
    if (!u) return u;
    u = String(u).replace(/&amp;/g, '&').replace(/\\u0026/g, '&');
    try { const x = new URL(u); x.hash = ''; return x.toString(); }
    catch (e) { return u; }
  }

  function score(w, h) {
    w = w || 0; h = h || 0;
    return (w && h) ? w * h : Math.max(w, h);
  }

  function bestVideoUrl(node) {
    const vv = node.video_versions || node.videoVersions;
    if (Array.isArray(vv) && vv.length) {
      const best = vv.slice().sort((a, b) => score(b.width, b.height) - score(a.width, a.height))[0];
      return best && best.url ? cleanUrl(best.url) : null;
    }
    return node.video_url ? cleanUrl(node.video_url) : null;
  }

  function bestImageUrl(node) {
    const iv = node.image_versions2 || node.imageVersions2;
    if (iv && Array.isArray(iv.candidates) && iv.candidates.length) {
      const best = iv.candidates.slice().sort((a, b) => score(b.width, b.height) - score(a.width, a.height))[0];
      return best && best.url ? cleanUrl(best.url) : null;
    }
    return node.display_url ? cleanUrl(node.display_url) : null;
  }

  function itemFrom(node) {
    if (!node || typeof node !== 'object') return null;
    const v = bestVideoUrl(node);
    if (v) return { type: 'video', url: v };
    const i = bestImageUrl(node);
    if (i) return { type: 'image', url: i };
    return null;
  }

  function captionOf(node) {
    if (node.caption && node.caption.text) return node.caption.text;
    const cap = node.edge_media_to_caption || node.edge_media_to_caption_;
    if (cap && cap.edges && cap.edges.length) return cap.edges[0].node.text || '';
    return '';
  }

  function authorOf(node) {
    if (node.owner && node.owner.username) return node.owner.username;
    if (node.user && node.user.username) return node.user.username;
    return '';
  }

  function shortcodeFromPath(p) {
    const m = (p || '').match(/\/(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/);
    return m ? m[2] : null;
  }

  // pull the shortcode out of a request URL's `variables={"shortcode":"..."}`
  function shortcodeFromRequest(u) {
    const m = (u || '').match(/shortcode[^A-Za-z0-9_-]{0,12}([A-Za-z0-9_-]{8,15})/i);
    return m ? m[1] : null;
  }

  function extractMedia(json, sc) {
    if (sc && sc.indexOf('/') !== -1) sc = shortcodeFromPath(sc);
    if (!sc) return null;

    let best = null;
    function walk(obj, depth) {
      if (!obj || typeof obj !== 'object' || depth > 80) return;
      if (Array.isArray(obj)) { for (const o of obj) walk(o, depth + 1); return; }

      if (obj.shortcode === sc || obj.code === sc) {
        const items = [];
        let car = obj.carousel_media || obj.carouselMedia;
        if (!car && obj.edge_sidecar_to_children) {
          car = (obj.edge_sidecar_to_children.edges || []).map((e) => (e && e.node) || e);
        }
        if (Array.isArray(car) && car.length) {
          for (const c of car) {
            const node = (c && c.node) || c;
            const it = itemFrom(node);
            if (it) items.push(it);
          }
        } else {
          const it = itemFrom(obj);
          if (it) items.push(it);
        }
        if (items.length) {
          best = {
            shortcode: sc,
            items,
            author: authorOf(obj),
            caption: captionOf(obj),
            timestamp: obj.taken_at || obj.takenAt || null,
          };
        }
        return;
      }
      for (const k in obj) walk(obj[k], depth + 1);
    }
    walk(json, 0);
    return best;
  }

  function capture(text, sc) {
    if (!text || typeof text !== 'string' || text.length < 20 || !sc) return;
    try {
      const j = JSON.parse(text);
      const found = extractMedia(j, sc);
      if (found && found.items && found.items.length) {
        // keep the fullest list we've seen for this shortcode
        if (!store.media ||
            store.media.shortcode !== found.shortcode ||
            found.items.length >= (store.media.items || []).length) {
          store.media = found;
        }
        try {
          document.dispatchEvent(new CustomEvent('__instaScrapeData', { detail: store.media }));
        } catch (e) { /* ignore */ }
      }
    } catch (e) { /* ignore non-JSON */ }
  }

  function isApiUrl(u) {
    return /instagram\.com\/(api|graphql|ajax)/.test(u);
  }

  // ---------------------------------------------------------------- XHR
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__instaUrl = typeof url === 'string' ? url : (url && url.url) || '';
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    try {
      this.addEventListener('load', () => {
        try {
          const u = this.__instaUrl || '';
          if (isApiUrl(u) && this.responseText) {
            const reqSC = shortcodeFromRequest(u);
            if (reqSC) store.lastSC = reqSC;
            capture(this.responseText, reqSC || shortcodeFromPath(location.pathname) || store.lastSC);
          }
        } catch (e) { /* ignore */ }
      });
    } catch (e) { /* ignore */ }
    return origSend.apply(this, arguments);
  };

  // ---------------------------------------------------------------- fetch
  const origFetch = window.fetch;
  if (typeof origFetch === 'function') {
    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const p = origFetch.apply(this, arguments);
      if (isApiUrl(url)) {
        const reqSC = shortcodeFromRequest(url);
        if (reqSC) store.lastSC = reqSC;
        try {
          p.then((res) => {
            try { res.clone().text().then((t) => capture(t, reqSC || shortcodeFromPath(location.pathname) || store.lastSC)); }
            catch (e) { /* ignore */ }
          }).catch(() => { /* ignore */ });
        } catch (e) { /* ignore */ }
      }
      return p;
    };
  }

  // ---------------------------------------------------------------- Response.json
  // More reliable than clone().text(): runs after Instagram parses the body,
  // so there is no stream-locking race. Falls back to the last shortcode seen
  // in an API request when the current path is a feed/profile (modal view).
  const origJson = Response.prototype.json;
  if (typeof origJson === 'function') {
    Response.prototype.json = function () {
      const p = origJson.apply(this, arguments);
      try {
        p.then((j) => {
          try { capture(JSON.stringify(j), shortcodeFromPath(location.pathname) || store.lastSC); }
          catch (e) { /* ignore */ }
        }).catch(() => { /* ignore */ });
      } catch (e) { /* ignore */ }
      return p;
    };
  }

  // ---------------------------------------------------------------- handshake
  document.addEventListener('__instaScrapeRequest', (ev) => {
    const id = ev.detail && ev.detail.id;
    try {
      document.dispatchEvent(new CustomEvent('__instaScrapeReply', { detail: { id, data: store.media } }));
    } catch (e) { /* ignore */ }
  });

  // test hook (used by node unit tests; harmless in the browser)
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { extractMedia, itemFrom, cleanUrl, bestVideoUrl, bestImageUrl, shortcodeFromRequest };
  }
})();
