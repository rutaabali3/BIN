// background.js — minimal MV3 service worker.
// The popup handles scanning and downloading; this worker only needs to exist
// so the manifest's background entry is valid.
chrome.runtime.onInstalled.addListener(() => {
  console.log('Insta Scraper extension installed.');
});
