# 📥 Insta Scraper

Save **all media from an Instagram share link** — single image, single video, or a
**carousel (multiple posts in one)** — packed into one `.zip` file:

```
insta_DcmL23RDUpA.zip
├── 01_video.mp4        ← 1st item
├── 02_video.mp4        ← 2nd item
├── 03_image.jpg        ← ...
└── metadata.json       ← author, caption, timestamps, per-item info
```

There are **two tools** in this workspace. Pick one:

| Tool | Best when | Where |
|---|---|---|
| 🌐 **Browser extension** (`insta-extension/`) | You're logged into Instagram in Chrome/Edge and want a 2-click "Download ZIP" | **recommended** |
| 🐍 **Python CLI** (`insta_scraper.py`) | You want automation / scripts / bulk links | needs cookies or password |

---

## 🌐 Browser extension (recommended)

### Install (2 minutes)

1. **Chrome / Edge** → go to `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (toggle, top-right).
3. Click **Load unpacked** → select the **`insta-extension`** folder.
4. Open your Instagram post/reel/carousel page **and refresh it** (so the
   extension can read the post data).

### Use

1. Open the post you want (e.g. your link `…/p/DcmL23RDUpA/`).
2. Click the extension icon → **1 · Scan this post**.
3. Click **2 · Download ZIP** → choose where to save.

The result is a zip with every image/video in the post, in order, plus
`metadata.json` (author, caption, timestamps).

**How it works:** the extension reads Instagram's own data *inside your logged-in
browser*, so no password or cookies ever leave your machine. It can't see posts
you can't already see (private posts require you to follow the account).

> Note: media is assembled in the popup, so keep the popup open while it
> downloads (it shows live progress).

---

## 🐍 Python CLI (for automation)

```bash
pip install yt-dlp
python insta_scraper.py "<share link>" --cookies cookies.txt
python insta_scraper.py URL1 URL2 URL3 -o downloads
python insta_scraper.py -f links.txt --cookies cookies.txt
```

### Authentication (Instagram blocks anonymous downloads)

One of:
- `--cookies cookies.txt` — export with the *"Get cookies.txt LOCALLY"* browser extension
- `--cookies-from-browser chrome` (or firefox/edge/brave)
- `--username USER --password PASS` (may trigger 2FA)

| Flag | Purpose |
|---|---|
| `--cookies FILE` | Netscape cookies.txt (recommended) |
| `--cookies-from-browser NAME` | read cookies from a local browser |
| `--username` / `--password` | password login |
| `-o DIR` / `--out DIR` | output folder (default `downloads`) |
| `--no-zip` | keep raw files instead of zipping |
| `-f FILE` | read links from a text file |
| `--proxy URL` | route through a proxy |

Run `python insta_scraper.py -h` for the full list.

---

## Notes

- Only download content you have the right to save (your own posts, or with
  permission). Respect Instagram's Terms of Service and copyright law.
- If a post fails: refresh the page, make sure you're logged in, and re-scan.
