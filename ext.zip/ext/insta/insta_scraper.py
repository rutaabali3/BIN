#!/usr/bin/env python3
"""
insta_scraper.py — Instagram post / reel / carousel downloader & zipper.

Give it one or more Instagram *share links* (posts, reels, or carousels) and it
will:

  * detect the post type  (single image / single video / carousel)
  * download EVERY piece of media in the post (images, videos, audio)
  * save a metadata.json (caption, author, timestamp, per-item info)
  * pack everything into ONE .zip file

Requirements
------------
    pip install yt-dlp

Authentication (REQUIRED for most posts)
----------------------------------------
Instagram blocks anonymous media downloads. Provide ONE of:

    # 1) a Netscape cookies.txt exported from your logged-in browser
    python insta_scraper.py URL --cookies cookies.txt

    # 2) read cookies straight from a browser on this machine
    python insta_scraper.py URL --cookies-from-browser chrome
    python insta_scraper.py URL --cookies-from-browser firefox

    # 3) username/password  (may trigger a 2FA / challenge)
    python insta_scraper.py URL --username YOU --password SECRET

Examples
--------
    python insta_scraper.py "https://www.instagram.com/p/DcmL23RDUpA/?utm_source=ig_web_copy_link&igsh=..."
    python insta_scraper.py URL1 URL2 URL3 --out downloads --cookies cookies.txt
    python insta_scraper.py links.txt            # one URL per line
    python insta_scraper.py DcmL23RDUpA          # bare shortcode also works
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    import yt_dlp
except ImportError:
    sys.exit("Missing dependency. Install it with:  pip install yt-dlp")

SHORTCODE_RE = re.compile(r"^[A-Za-z0-9_-]{8,15}$")


# --------------------------------------------------------------------------- #
# URL helpers
# --------------------------------------------------------------------------- #
def normalize_url(text: str) -> str:
    """Turn a share link, short link, or bare shortcode into a canonical URL."""
    text = text.strip().strip("\"'")
    if not text:
        raise ValueError("empty input")

    # bare shortcode, e.g.  DcmL23RDUpA
    if SHORTCODE_RE.match(text) and "/" not in text:
        return f"https://www.instagram.com/p/{text}/"

    # find the shortcode inside any instagram URL
    m = re.search(r"instagram\.com/(?:p|reel|reels|tv|stories/[^/]+)/([A-Za-z0-9_-]+)", text)
    if not m:
        m = re.search(r"instagr\.am/(?:p|reel|tv)/([A-Za-z0-9_-]+)", text)
    if m:
        return f"https://www.instagram.com/p/{m.group(1)}/"
    raise ValueError(f"could not find an Instagram shortcode in: {text}")


def shortcode_from_url(url: str) -> str:
    m = re.search(r"instagram\.com/(?:p|reel|reels|tv)/?([A-Za-z0-9_-]+)", url)
    return m.group(1) if m else "post"


# --------------------------------------------------------------------------- #
# Post type helpers
# --------------------------------------------------------------------------- #
def entry_kind(entry: dict) -> str:
    """Classify one yt-dlp entry as video / image / audio."""
    for f in entry.get("formats") or []:
        vc = (f.get("vcodec") or "").lower()
        ac = (f.get("acodec") or "").lower()
        if vc and vc != "none":
            return "video"
        if ac and ac != "none" and not vc:
            return "audio"
    if entry.get("duration"):
        return "video"
    return "image"


def classify(info: dict) -> str:
    entries = info.get("entries")
    if entries:
        return "carousel"  # multiple media in one post
    return entry_kind(info)


def describe(info: dict) -> str:
    entries = info.get("entries")
    if entries:
        kinds = [entry_kind(e) for e in entries]
        n = len(kinds)
        nv = kinds.count("video")
        ni = kinds.count("image")
        parts = []
        if nv:
            parts.append(f"{nv} video{'s' if nv != 1 else ''}")
        if ni:
            parts.append(f"{ni} image{'s' if ni != 1 else ''}")
        return f"carousel ({n} items: {', '.join(parts) or 'mixed'})"
    return entry_kind(info)


# --------------------------------------------------------------------------- #
# Core scraper
# --------------------------------------------------------------------------- #
def scrape_one(url: str, ydl_opts: dict, out_dir: Path, make_zip: bool) -> Path | None:
    url = normalize_url(url)
    sc = shortcode_from_url(url)
    workdir = Path(tempfile.mkdtemp(prefix=f"insta_{sc}_"))

    opts = dict(ydl_opts)
    opts["outtmpl"] = str(workdir / "%(id)s.%(ext)s")
    opts["quiet"] = True
    opts["no_warnings"] = True
    opts["noplaylist"] = False          # download every carousel item
    opts["ignoreerrors"] = False

    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
    except yt_dlp.utils.DownloadError as e:
        msg = str(e)
        shutil.rmtree(workdir, ignore_errors=True)
        if re.search(r"login|sign in|challenge|No video formats|not found", msg, re.I):
            raise AuthError(
                f"{url}\n  -> Instagram refused to serve media without authentication. "
                f"Re-run with --cookies cookies.txt, --cookies-from-browser BROWSER, "
                f"or --username/--password."
            ) from e
        raise RuntimeError(f"{url}\n  -> {msg}") from e

    if info is None:
        shutil.rmtree(workdir, ignore_errors=True)
        raise RuntimeError(f"{url} -> no data returned (post may be private or removed)")

    # normalize (a carousel comes back as a playlist dict)
    if isinstance(info, dict) and info.get("entries") is None:
        entries = [info]
    else:
        entries = list(info.get("entries") or [info])

    kind = classify(info)
    print(f"  ✓ {url}")
    print(f"    type   : {kind}")
    if entries:
        uploader = entries[0].get("uploader") or entries[0].get("channel") or "unknown"
        print(f"    author : {uploader}")
    print(f"    items  : {len(entries)}")

    return _assemble_zip(workdir, entries, url, sc, kind, out_dir)


def _assemble_zip(workdir: Path, entries: list, url: str, sc: str, kind: str, out_dir: Path) -> Path:
    """Match downloaded files to entries, write metadata.json, and zip it all."""
    # ---- map every entry to the file yt-dlp wrote on disk ---------------- #
    files_on_disk = sorted(p for p in workdir.iterdir() if p.is_file())
    id_to_file = {}
    for p in files_on_disk:
        stem = p.name.split(".")[0]
        id_to_file[stem] = p

    manifest = []
    media = []  # (src_path, zip_name)
    for i, e in enumerate(entries, 1):
        eid = e.get("id") or str(i)
        path = id_to_file.get(eid)
        # fallback: match any file we haven't claimed yet (ordering)
        if path is None and i <= len(files_on_disk):
            path = files_on_disk[i - 1]

        k = entry_kind(e)
        ext = path.suffix.lstrip(".") if path else ({"video": "mp4", "image": "jpg"}.get(k, "bin"))
        zip_name = f"{i:02d}_{k}.{ext}"

        item_meta = {
            "index": i,
            "id": eid,
            "type": k,
            "title": e.get("title") or "",
            "webpage_url": e.get("webpage_url") or url,
            "timestamp": int(e.get("timestamp") or 0),
            "file": zip_name if path else None,
            "size_bytes": path.stat().st_size if path else None,
        }
        manifest.append(item_meta)
        if path and path.exists():
            media.append((path, zip_name))

    if not media:
        shutil.rmtree(workdir, ignore_errors=True)
        raise RuntimeError(f"{url} -> nothing was downloaded (0 media files).")

    # ---- metadata.json ---------------------------------------------------- #
    first = entries[0]
    ts = first.get("timestamp") or int(time.time())
    meta = {
        "source_url": url,
        "shortcode": sc,
        "post_type": kind,
        "author": first.get("uploader") or first.get("channel") or "",
        "author_id": first.get("uploader_id") or first.get("channel_id") or "",
        "caption": first.get("description") or first.get("title") or "",
        "timestamp": ts,
        "scraped_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "item_count": len(entries),
        "items": manifest,
    }
    meta_path = workdir / "metadata.json"
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    # ---- zip everything --------------------------------------------------- #
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / f"insta_{sc}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(meta_path, "metadata.json")
        for src, name in media:
            zf.write(src, name)

    total = sum(m["size_bytes"] or 0 for m in manifest)
    print(f"    packed : {zip_path.name}  ({len(media)} files, {human(total)})")

    shutil.rmtree(workdir, ignore_errors=True)
    return zip_path


class AuthError(RuntimeError):
    pass


def human(nbytes: int) -> str:
    n = float(nbytes)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main() -> int:
    ap = argparse.ArgumentParser(
        description="Download all media from Instagram share links and zip them.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    ap.add_argument("links", nargs="*", help="Instagram share links (or a .txt file of links)")
    ap.add_argument("-f", "--file", help="text file with one link per line")
    ap.add_argument("-o", "--out", default="downloads", help="output folder (default: downloads)")
    ap.add_argument("--no-zip", action="store_true", help="keep raw files, skip zipping")
    ap.add_argument("--cookies", help="Netscape cookies.txt file (recommended)")
    ap.add_argument("--cookies-from-browser", help="read cookies from a browser: chrome|firefox|edge|safari|brave")
    ap.add_argument("--username", help="Instagram username (may trigger 2FA)")
    ap.add_argument("--password", help="Instagram password")
    ap.add_argument("--proxy", help="proxy URL, e.g. http://127.0.0.1:8080")
    args = ap.parse_args()

    links = list(args.links)
    if args.file:
        links += [ln.strip() for ln in Path(args.file).read_text().splitlines() if ln.strip()]
    if not links:
        ap.error("provide at least one link, or -f links.txt")

    ydl_opts = {
        "retries": 10,
        "fragment_retries": 10,
        "socket_timeout": 60,
        "http_headers": {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "en-US,en;q=0.9",
        },
    }
    if args.cookies:
        ydl_opts["cookiefile"] = args.cookies
    if args.cookies_from_browser:
        ydl_opts["cookiesfrombrowser"] = (args.cookies_from_browser,)
    if args.username:
        ydl_opts["username"] = args.username
    if args.password:
        ydl_opts["password"] = args.password
    if args.proxy:
        ydl_opts["proxy"] = args.proxy
    if not args.cookies and not args.cookies_from_browser and not args.username:
        print("⚠  No authentication provided — Instagram may refuse media for many posts.\n"
              "   Use --cookies cookies.txt, --cookies-from-browser chrome, or --username/--password.\n")

    out_dir = Path(args.out)
    zips, errors = [], []
    for link in links:
        try:
            z = scrape_one(link, ydl_opts, out_dir, make_zip=not args.no_zip)
            if z:
                zips.append(z)
        except AuthError as e:
            print("  ✗", e)
            errors.append(link)
        except Exception as e:  # noqa: BLE001
            print("  ✗", e)
            errors.append(link)

    print("\n" + "=" * 60)
    if zips:
        print("Done. Zipped:", ", ".join(z.name for z in zips))
    if errors:
        print(f"Failed ({len(errors)}):")
        for u in errors:
            print("  -", u)
        print("\nTip: export your Instagram cookies (see README.md) and re-run with --cookies.")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
