// Time Capsule Application
class TimeCapsuleApp {
    constructor() {
        this.capsules = [];
        this.filteredCapsules = [];
        this.currentSection = 'explore';
        this.reactions = this.loadReactions();
        this.userCapsules = this.loadUserCapsules();
        
        this.init();
    }

    async init() {
        await this.loadCapsules();
        this.setupEventListeners();
        this.setupTheme();
        this.renderCapsules();
        this.renderTimeline();
        this.renderMemorySpotlight();
        this.startCountdownUpdates();
        this.initAOS();
    }

    // Data Management
    async loadCapsules() {
        try {
            const response = await fetch('data/capsules.json');
            const data = await response.json();
            this.capsules = [...data, ...this.userCapsules];
            this.filteredCapsules = [...this.capsules];
        } catch (error) {
            console.error('Error loading capsules:', error);
            this.capsules = [...this.userCapsules];
            this.filteredCapsules = [...this.capsules];
        }
    }

    loadReactions() {
        const saved = localStorage.getItem('timeCapsule_reactions');
        return saved ? JSON.parse(saved) : {};
    }

    saveReactions() {
        localStorage.setItem('timeCapsule_reactions', JSON.stringify(this.reactions));
    }

    loadUserCapsules() {
        const saved = localStorage.getItem('timeCapsule_userCapsules');
        return saved ? JSON.parse(saved) : [];
    }

    saveUserCapsules() {
        localStorage.setItem('timeCapsule_userCapsules', JSON.stringify(this.userCapsules));
    }

    // Event Listeners
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchSection(e.target.dataset.section);
            });
        });

        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            this.toggleTheme();
        });

        // Search and filter
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterCapsules();
        });

        document.getElementById('sortFilter').addEventListener('change', () => {
            this.filterCapsules();
        });

        document.getElementById('statusFilter').addEventListener('change', () => {
            this.filterCapsules();
        });

        // Form submission
        document.getElementById('submissionForm').addEventListener('submit', (e) => {
            this.handleSubmission(e);
        });

        // Character count
        document.getElementById('messageInput').addEventListener('input', (e) => {
            this.updateCharCount(e.target.value.length);
        });

        // Modal
        document.getElementById('modalClose').addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('capsuleModal').addEventListener('click', (e) => {
            if (e.target.id === 'capsuleModal') {
                this.closeModal();
            }
        });

        // Memory spotlight refresh
        document.getElementById('refreshSpotlight').addEventListener('click', () => {
            this.renderMemorySpotlight();
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });
    }

    // Theme Management
    setupTheme() {
        const savedTheme = localStorage.getItem('timeCapsule_theme') || 'light';
        document.body.className = `${savedTheme}-theme`;
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.body.className = `${newTheme}-theme`;
        localStorage.setItem('timeCapsule_theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const icon = document.querySelector('#themeToggle i');
        icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }

    // Navigation
    switchSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Update sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionName).classList.add('active');

        this.currentSection = sectionName;

        // Refresh content if needed
        if (sectionName === 'timeline') {
            this.renderTimeline();
        }
    }

    // Utility Functions
    isUnlocked(unlockDate) {
        return new Date() >= new Date(unlockDate);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getTimeRemaining(unlockDate) {
        const now = new Date().getTime();
        const unlock = new Date(unlockDate).getTime();
        const difference = unlock - now;

        if (difference <= 0) {
            return { expired: true };
        }

        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        return { days, hours, minutes, seconds, expired: false };
    }

    formatCountdown(timeRemaining) {
        if (timeRemaining.expired) {
            return 'Unlocked!';
        }

        const { days, hours, minutes, seconds } = timeRemaining;
        
        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m ${seconds}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds}s`;
        } else {
            return `${seconds}s`;
        }
    }

    // Capsule Rendering
    renderCapsules() {
        const grid = document.getElementById('capsulesGrid');
        grid.innerHTML = '';

        if (this.filteredCapsules.length === 0) {
            grid.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No capsules found</h3>
                    <p>Try adjusting your search or filter criteria</p>
                </div>
            `;
            return;
        }

        this.filteredCapsules.forEach(capsule => {
            const capsuleElement = this.createCapsuleElement(capsule);
            grid.appendChild(capsuleElement);
        });
    }

    createCapsuleElement(capsule) {
        const isUnlocked = this.isUnlocked(capsule.unlockDate);
        const timeRemaining = this.getTimeRemaining(capsule.unlockDate);
        const userReactions = this.reactions[capsule.id] || {};

        const div = document.createElement('div');
        div.className = `capsule ${isUnlocked ? 'unlocked' : 'locked'}`;
        div.setAttribute('data-aos', 'fade-up');
        
        div.innerHTML = `
            <div class="capsule-header">
                <div class="capsule-status ${isUnlocked ? 'unlocked' : 'locked'}">
                    <i class="fas ${isUnlocked ? 'fa-unlock' : 'fa-lock'}"></i>
                    ${isUnlocked ? 'Unlocked' : 'Locked'}
                </div>
                <div class="capsule-author">by ${capsule.author}</div>
            </div>
            
            <div class="capsule-content">
                <div class="capsule-message">
                    ${isUnlocked ? capsule.message : this.getPreviewMessage(capsule.message)}
                </div>
                ${capsule.link && isUnlocked ? `
                    <a href="${capsule.link}" target="_blank" class="capsule-link">
                        <i class="fas fa-external-link-alt"></i>
                        View Link
                    </a>
                ` : ''}
            </div>
            
            <div class="capsule-footer">
                <div class="countdown ${timeRemaining.days <= 1 ? 'urgent' : ''}">
                    ${isUnlocked ? `Unlocked ${this.formatDate(capsule.unlockDate)}` : this.formatCountdown(timeRemaining)}
                </div>
                
                ${isUnlocked ? `
                    <div class="capsule-reactions">
                        <button class="reaction-btn ${userReactions.hearts ? 'active' : ''}" data-reaction="hearts" data-capsule="${capsule.id}">
                            <i class="fas fa-heart"></i>
                            <span>${(capsule.reactions.hearts || 0) + (userReactions.hearts || 0)}</span>
                        </button>
                        <button class="reaction-btn ${userReactions.stars ? 'active' : ''}" data-reaction="stars" data-capsule="${capsule.id}">
                            <i class="fas fa-star"></i>
                            <span>${(capsule.reactions.stars || 0) + (userReactions.stars || 0)}</span>
                        </button>
                        <button class="reaction-btn ${userReactions.minds ? 'active' : ''}" data-reaction="minds" data-capsule="${capsule.id}">
                            <i class="fas fa-brain"></i>
                            <span>${(capsule.reactions.minds || 0) + (userReactions.minds || 0)}</span>
                        </button>
                    </div>
                ` : ''}
            </div>
        `;

        // Add click handler for modal
        div.addEventListener('click', (e) => {
            if (!e.target.closest('.reaction-btn') && !e.target.closest('.capsule-link')) {
                this.openModal(capsule);
            }
        });

        // Add reaction handlers
        div.querySelectorAll('.reaction-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.handleReaction(e.target.closest('.reaction-btn'));
            });
        });

        return div;
    }

    getPreviewMessage(message) {
        const words = message.split(' ');
        const previewLength = Math.min(words.length, Math.floor(words.length * 0.3));
        return words.slice(0, previewLength).join(' ') + '...';
    }

    // Modal Management
    openModal(capsule) {
        const modal = document.getElementById('capsuleModal');
        const modalBody = document.getElementById('modalBody');
        const isUnlocked = this.isUnlocked(capsule.unlockDate);
        const timeRemaining = this.getTimeRemaining(capsule.unlockDate);

        modalBody.innerHTML = `
            <div class="modal-capsule">
                <div class="capsule-header">
                    <div class="capsule-status ${isUnlocked ? 'unlocked' : 'locked'}">
                        <i class="fas ${isUnlocked ? 'fa-unlock' : 'fa-lock'}"></i>
                        ${isUnlocked ? 'Unlocked' : 'Locked'}
                    </div>
                    <div class="capsule-author">by ${capsule.author}</div>
                </div>
                
                <div class="capsule-content">
                    <div class="capsule-message">
                        ${isUnlocked ? capsule.message : 'This message is locked until ' + this.formatDate(capsule.unlockDate)}
                    </div>
                    ${capsule.link && isUnlocked ? `
                        <a href="${capsule.link}" target="_blank" class="capsule-link">
                            <i class="fas fa-external-link-alt"></i>
                            ${capsule.link}
                        </a>
                    ` : ''}
                </div>
                
                <div class="capsule-footer">
                    <div class="countdown">
                        ${isUnlocked ? `Unlocked on ${this.formatDate(capsule.unlockDate)}` : `Unlocks in ${this.formatCountdown(timeRemaining)}`}
                    </div>
                    <div class="capsule-meta">
                        Created on ${this.formatDate(capsule.createdAt)}
                    </div>
                </div>
                
                <div class="share-section">
                    <button class="share-btn" onclick="navigator.clipboard.writeText(window.location.href + '#capsule-${capsule.id}')">
                        <i class="fas fa-share"></i>
                        Copy Share Link
                    </button>
                </div>
            </div>
        `;

        modal.classList.add('active');
        
        // Animate modal content
        gsap.fromTo(modalBody, 
            { opacity: 0, y: 20 },
            { opacity: 1, y: 0, duration: 0.3 }
        );
    }

    closeModal() {
        const modal = document.getElementById('capsuleModal');
        modal.classList.remove('active');
    }

    // Reactions
    handleReaction(button) {
        const capsuleId = button.dataset.capsule;
        const reactionType = button.dataset.reaction;
        
        if (!this.reactions[capsuleId]) {
            this.reactions[capsuleId] = {};
        }

        // Toggle reaction
        this.reactions[capsuleId][reactionType] = !this.reactions[capsuleId][reactionType];
        
        // Update UI
        button.classList.toggle('active');
        const countSpan = button.querySelector('span');
        const currentCount = parseInt(countSpan.textContent);
        countSpan.textContent = this.reactions[capsuleId][reactionType] ? currentCount + 1 : currentCount - 1;

        // Animate reaction
        gsap.fromTo(button, 
            { scale: 1 },
            { scale: 1.2, duration: 0.1, yoyo: true, repeat: 1 }
        );

        this.saveReactions();
    }

    // Search and Filter
    filterCapsules() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const sortBy = document.getElementById('sortFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;

        let filtered = [...this.capsules];

        // Apply search filter
        if (searchTerm) {
            filtered = filtered.filter(capsule => 
                capsule.message.toLowerCase().includes(searchTerm) ||
                capsule.author.toLowerCase().includes(searchTerm)
            );
        }

        // Apply status filter
        if (statusFilter !== 'all') {
            filtered = filtered.filter(capsule => {
                const isUnlocked = this.isUnlocked(capsule.unlockDate);
                return statusFilter === 'unlocked' ? isUnlocked : !isUnlocked;
            });
        }

        // Apply sorting
        filtered.sort((a, b) => {
            switch (sortBy) {
                case 'newest':
                    return new Date(b.createdAt) - new Date(a.createdAt);
                case 'oldest':
                    return new Date(a.createdAt) - new Date(b.createdAt);
                case 'unlock-soon':
                    return new Date(a.unlockDate) - new Date(b.unlockDate);
                case 'unlock-far':
                    return new Date(b.unlockDate) - new Date(a.unlockDate);
                default:
                    return 0;
            }
        });

        this.filteredCapsules = filtered;
        this.renderCapsules();
    }

    // Form Handling
    handleSubmission(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const author = document.getElementById('authorInput').value.trim();
        const message = document.getElementById('messageInput').value.trim();
        const imageURL = document.getElementById('imageInput').value.trim();
        const link = document.getElementById('linkInput').value.trim();
        const unlockDate = document.getElementById('unlockDateInput').value;

        // Validation
        if (!author || !message || !unlockDate) {
            alert('Please fill in all required fields.');
            return;
        }

        const unlockDateTime = new Date(unlockDate);
        if (unlockDateTime <= new Date()) {
            alert('Unlock date must be in the future.');
            return;
        }

        // Create new capsule
        const newCapsule = {
            id: Date.now().toString(),
            message,
            imageURL,
            link,
            unlockDate: unlockDateTime.toISOString(),
            author,
            createdAt: new Date().toISOString(),
            reactions: {
                hearts: 0,
                stars: 0,
                minds: 0
            }
        };

        // Add to user capsules
        this.userCapsules.push(newCapsule);
        this.capsules.push(newCapsule);
        this.saveUserCapsules();

        // Reset form
        e.target.reset();
        this.updateCharCount(0);

        // Show success message
        this.showSuccessMessage();

        // Refresh displays
        this.filterCapsules();
        this.renderTimeline();

        // Switch to explore section
        this.switchSection('explore');
    }

    updateCharCount(count) {
        document.getElementById('charCount').textContent = count;
    }

    showSuccessMessage() {
        const message = document.createElement('div');
        message.className = 'success-message';
        message.innerHTML = `
            <i class="fas fa-check-circle"></i>
            Time capsule created successfully!
        `;
        message.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--accent-green);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 4px;
            z-index: 1001;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 500;
        `;

        document.body.appendChild(message);

        // Animate in
        gsap.fromTo(message, 
            { opacity: 0, x: 100 },
            { opacity: 1, x: 0, duration: 0.3 }
        );

        // Remove after 3 seconds
        setTimeout(() => {
            gsap.to(message, {
                opacity: 0,
                x: 100,
                duration: 0.3,
                onComplete: () => message.remove()
            });
        }, 3000);
    }

    // Timeline
    renderTimeline() {
        const container = document.getElementById('timelineContainer');
        const futureCapsules = this.capsules
            .filter(capsule => !this.isUnlocked(capsule.unlockDate))
            .sort((a, b) => new Date(a.unlockDate) - new Date(b.unlockDate))
            .slice(0, 10);

        if (futureCapsules.length === 0) {
            container.innerHTML = `
                <div class="no-timeline">
                    <i class="fas fa-clock"></i>
                    <h3>No upcoming unlocks</h3>
                    <p>All capsules have been unlocked or create a new one!</p>
                </div>
            `;
            return;
        }

        const timeline = document.createElement('div');
        timeline.className = 'timeline';

        futureCapsules.forEach(capsule => {
            const timeRemaining = this.getTimeRemaining(capsule.unlockDate);
            const item = document.createElement('div');
            item.className = 'timeline-item';
            item.setAttribute('data-aos', 'fade-up');
            
            item.innerHTML = `
                <div class="timeline-date">${this.formatDate(capsule.unlockDate)}</div>
                <div class="timeline-countdown">${this.formatCountdown(timeRemaining)}</div>
                <div class="timeline-author">${capsule.author}</div>
            `;

            item.addEventListener('click', () => {
                this.openModal(capsule);
            });

            timeline.appendChild(item);
        });

        container.innerHTML = '';
        container.appendChild(timeline);
    }

    // Memory Spotlight
    renderMemorySpotlight() {
        const unlockedCapsules = this.capsules.filter(capsule => this.isUnlocked(capsule.unlockDate));
        
        if (unlockedCapsules.length === 0) {
            document.getElementById('spotlightContent').innerHTML = `
                <div class="no-spotlight">
                    <i class="fas fa-hourglass-empty"></i>
                    <p>No unlocked memories yet. Check back later!</p>
                </div>
            `;
            return;
        }

        const randomCapsule = unlockedCapsules[Math.floor(Math.random() * unlockedCapsules.length)];
        const spotlightElement = this.createCapsuleElement(randomCapsule);
        spotlightElement.classList.add('spotlight-capsule');

        document.getElementById('spotlightContent').innerHTML = '';
        document.getElementById('spotlightContent').appendChild(spotlightElement);

        // Animate spotlight
        gsap.fromTo(spotlightElement, 
            { opacity: 0, scale: 0.95 },
            { opacity: 1, scale: 1, duration: 0.5 }
        );
    }

    // Countdown Updates
    startCountdownUpdates() {
        setInterval(() => {
            this.updateCountdowns();
        }, 1000);
    }

    updateCountdowns() {
        document.querySelectorAll('.countdown').forEach(element => {
            const capsuleElement = element.closest('.capsule');
            if (!capsuleElement) return;

            const capsuleId = capsuleElement.querySelector('[data-capsule]')?.dataset.capsule;
            if (!capsuleId) return;

            const capsule = this.capsules.find(c => c.id === capsuleId);
            if (!capsule) return;

            const timeRemaining = this.getTimeRemaining(capsule.unlockDate);
            
            if (timeRemaining.expired && !this.isUnlocked(capsule.unlockDate)) {
                // Capsule just unlocked - trigger unlock animation
                this.triggerUnlockAnimation(capsuleElement, capsule);
            } else if (!timeRemaining.expired) {
                element.textContent = this.formatCountdown(timeRemaining);
                element.className = `countdown ${timeRemaining.days <= 1 ? 'urgent' : ''}`;
            }
        });
    }

    triggerUnlockAnimation(capsuleElement, capsule) {
        // Update capsule status
        capsuleElement.classList.remove('locked');
        capsuleElement.classList.add('unlocked');

        // Animate unlock
        gsap.timeline()
            .to(capsuleElement, { scale: 1.05, duration: 0.2 })
            .to(capsuleElement, { scale: 1, duration: 0.2 })
            .fromTo(capsuleElement.querySelector('.capsule-content'), 
                { filter: 'blur(1px)' },
                { filter: 'blur(0px)', duration: 0.5 }
            );

        // Re-render the capsule with unlocked content
        setTimeout(() => {
            this.renderCapsules();
        }, 1000);
    }

    // Initialize AOS (Animate On Scroll)
    initAOS() {
        AOS.init({
            duration: 600,
            easing: 'ease-out-cubic',
            once: true,
            offset: 50
        });
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TimeCapsuleApp();
});

// Add some additional CSS for success message and other dynamic elements
const additionalStyles = `
    .no-results, .no-timeline, .no-spotlight {
        text-align: center;
        padding: var(--spacing-12);
        color: var(--text-secondary);
    }

    .no-results i, .no-timeline i, .no-spotlight i {
        font-size: var(--font-size-4xl);
        color: var(--text-muted);
        margin-bottom: var(--spacing-4);
    }

    .no-results h3, .no-timeline h3 {
        font-size: var(--font-size-xl);
        margin-bottom: var(--spacing-2);
        color: var(--text-primary);
    }

    .spotlight-capsule {
        border-color: var(--accent-green) !important;
        box-shadow: 0 0 20px rgba(36, 207, 166, 0.2);
    }

    .timeline-countdown {
        font-size: var(--font-size-sm);
        color: var(--text-secondary);
        margin-bottom: var(--spacing-2);
    }

    .share-section {
        margin-top: var(--spacing-6);
        padding-top: var(--spacing-4);
        border-top: 1px solid var(--border-light);
    }

    .share-btn {
        display: flex;
        align-items: center;
        gap: var(--spacing-2);
        padding: var(--spacing-3) var(--spacing-4);
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        color: var(--text-secondary);
        font-size: var(--font-size-sm);
        cursor: pointer;
        transition: all var(--transition-fast);
        width: 100%;
        justify-content: center;
    }

    .share-btn:hover {
        border-color: var(--accent-green);
        color: var(--accent-green);
    }

    .capsule-meta {
        font-size: var(--font-size-xs);
        color: var(--text-muted);
        text-align: right;
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

