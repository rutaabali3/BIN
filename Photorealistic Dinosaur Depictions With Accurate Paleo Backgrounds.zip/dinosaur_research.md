

## Tyrannosaurus rex

*   **Geological Period:** Late Cretaceous (66-68 million years ago)
*   **Habitat:** Western North America (Laramidia), including inland and coastal subtropical and semi-arid plains. Environment dominated by bald cypress, sequoia-like conifers, ferns, cycads, palms, and flowering shrubs.
*   **Anatomical Features:** Large, robust skull with powerful jaws and sharp, serrated teeth. Short forelimbs. Long, powerful tail. Muscular body, up to 40 feet long.



## Triceratops horridus

*   **Geological Period:** Late Cretaceous (66-68 million years ago)
*   **Habitat:** North America. Environment likely included bonebeds, suggesting herd behavior.
*   **Anatomical Features:** Large, elongated skull with three horns (one short nasal horn, two long brow horns up to 1 meter). Large bony frill behind the horns. Parrot-like beak and rows of shearing teeth for grinding tough plant material. Up to 30 feet long and 10 feet tall.



## Velociraptor mongoliensis

*   **Geological Period:** Late Cretaceous (70-75 million years ago)
*   **Habitat:** Gobi Desert of Mongolia and China. Arid environments.
*   **Anatomical Features:** Bipedal, feathered carnivore. Small (turkey-sized, about 6-7 feet long). Long tail for balance. Enlarged sickle-shaped claw on the second toe of each hindfoot. Long, three-clawed hands. S-shaped neck. Skull up to 9.8 inches long, uniquely up-curved with jaws lined with 26–28 widely spaced, serrated teeth.



## Brachiosaurus altithorax

*   **Geological Period:** Late Jurassic (155.6 to 145.5 million years ago), possibly extending into the Cretaceous.
*   **Habitat:** North America, prominently in the Morrison Formation (western region of the US). Likely inhabited open plains and forested areas.
*   **Anatomical Features:** Huge sauropod with a disproportionately long neck and tail, small head, and large trunk. Forelimbs were longer than hind limbs, giving it a giraffe-like stance. Deep chest. Columnar limbs.



## Stegosaurus stenops

*   **Geological Period:** Late Jurassic (Kimmeridgian to Early Tithonian, around 155 to 145 million years ago).
*   **Habitat:** Western North America. Likely inhabited areas with abundant vegetation.
*   **Anatomical Features:** Large, heavily built herbivorous quadruped. Distinctive rows of large, bony plates along its back and four large spikes (thagomizer) on its tail. Short forelimbs and long hind limbs, giving it an arched back appearance. Small head with a toothless beak in front. Short and broad feet.



## Allosaurus fragilis

*   **Geological Period:** Late Jurassic (156 to 145 million years ago)
*   **Habitat:** North America (Morrison Formation) and Portugal (Lourinha Formation). Semi-arid floodplains with distinct wet and dry seasons, gallery forests, and both lush and arid environments.
*   **Anatomical Features:** Large bipedal predator. Light, robust skull with dozens of sharp, serrated teeth. Snout narrower than the back of the skull. Stoutly built for predation.



## Ankylosaurus magniventris

*   **Geological Period:** Late Cretaceous (68-66 million years ago)
*   **Habitat:** North America. Likely inhabited areas with lush vegetation.
*   **Anatomical Features:** Heavily armored quadruped with bony plates (osteoderms) covering its body, some keeled. Bony half-rings covering the neck. Large club on the end of its tail. Squat, flat, and wide body. Length between 6 and 8 meters (19.7 and 26.2 feet).



## Spinosaurus aegyptiacus

*   **Geological Period:** Late Cretaceous (99-93.5 million years ago)
*   **Habitat:** North Africa. Tidal flats (muddy or marshy areas covered by the sea) and mangrove forests. Likely fed primarily from the water.
*   **Anatomical Features:** Distinctive tall dorsal sail formed from elongated neural spines. Long, narrow, crocodilian-like skull with nostrils near the eyes. Muscular shoulders and relatively long forearms. Exhibited a blend of terrestrial and aquatic adaptations.



## Diplodocus longus

*   **Geological Period:** Late Jurassic (around 154 to 152 million years ago).
*   **Habitat:** North America. Hot and dry savannah-like environment with tree ferns and cycads.
*   **Anatomical Features:** Typical sauropod shape with a very long neck and tail (around 80 vertebrae in the tail alone). Four sturdy, pillar-like legs, with forelimbs slightly shorter than hind limbs. Long, whip-like tail. Two rows of bones on the underside of its tail.



## Parasaurolophus walkeri

*   **Geological Period:** Late Cretaceous (Campanian to possibly Maastrichtian Ages, 76.9 - 66 million years ago).
*   **Habitat:** Western North America (Alberta, New Mexico, Utah). Warm, lush areas, coastal and floodplain environments.
*   **Anatomical Features:** Hadrosaurid ("duck-billed") dinosaur. Distinctive long, narrow, backward-curving crest rising from the skull (about 1.6 meters long including crest). Generalist herbivore with small scales and a tall build.



## Carnotaurus sastrei

*   **Geological Period:** Late Cretaceous (Cenomanian age, around 99.6 to 95 million years ago).
*   **Habitat:** Patagonia, Argentina. Climatically similar to its ancestors' habitats, likely including open plains and forested regions.
*   **Anatomical Features:** Large, lightly built theropod. Two thick horns above the eyes. Very deep skull on a muscular neck. Unusually short snout and narrow head. Very small arms. Knife-like teeth. Well-preserved skin impressions show pebbly scales.



## Pachycephalosaurus wyomingensis

*   **Geological Period:** Late Cretaceous (Maastrichtian age, 76 to 65 million years ago).
*   **Habitat:** Western North America (Montana, South Dakota, Wyoming). Varied habitats from coastal plains to dense forests, open plains, and sheltering structures with fruit-bearing plants.
*   **Anatomical Features:** Distinctive dome-shaped skull (up to 36 cm long and 25-30 cm thick) with gnarly spikes and a dense bony dome. Short skull with blunt spikes. Large rounded eye sockets. Thick neck, short forelimbs, long hindlimbs, bulky body, and a heavy tail held rigid by ossified tendons. Dentition with leaf-shaped crowns and a pointed beak-like muzzle.



## Giganotosaurus carolinii

*   **Geological Period:** Late Cretaceous (early Cenomanian age, 99.6 to 95 million years ago).
*   **Habitat:** Argentina. Primarily occupied open plains and forested regions, dense forests, and abundant rivers.
*   **Anatomical Features:** Large theropod. Large head with a blunted chin. Dozens of serrated teeth up to 20 cm long. Long tail. Skull larger than T. rex (1.6m vs 1.53m).



## Iguanodon bernissartensis

*   **Geological Period:** Late Jurassic to Early Cretaceous (161.2 to 99.6 million years ago).
*   **Habitat:** Europe. Likely diverse environments, including forests and plains.
*   **Anatomical Features:** Large herbivorous ornithopod. Distinctive large thumb spikes, possibly for defense. Long prehensile fifth fingers. Large skull with a toothless beak and closely bundled, diamond-shaped teeth in the cheek. Could switch between bipedal and quadrupedal movement. Up to 10 meters long.



## Apatosaurus ajax

*   **Geological Period:** Late Jurassic (Tithonian, 150-145 million years ago).
*   **Habitat:** North America (Arizona, South Dakota, Utah, Wyoming, Oklahoma). Lived near gallery forests along riversides in semi-arid, prairie-like environments.
*   **Anatomical Features:** Large, heavily built herbivorous sauropod. Long neck and a long, whip-like tail. Sturdier legs than other sauropods, with hind limbs larger than forelimbs. Air sacs in vertebrae to lighten bones. Generalized browser, likely held its head elevated.



## Coelophysis bauri

*   **Geological Period:** Late Triassic (216 to 203 million years ago).
*   **Habitat:** Southwestern United States. 
*   **Anatomical Features:** Small, slenderly built, bipedal carnivore. Long, muscular rear legs with three-toed, clawed feet. Shorter, thinner, but muscular arms. Light, slender body adapted for running, balanced by a long neck and tail. Flat head. Up to 3 meters (9.8 feet) long.



## Corythosaurus casuarius

*   **Geological Period:** Late Cretaceous (77–75.7 million years ago).
*   **Habitat:** Woodland forests, possibly swampy areas. Found in Alberta, Canada.
*   **Anatomical Features:** Hadrosaurid (duck-billed) dinosaur. Hollow, bony crest on top of its long head, shaped like a helmet. Flat, duck-billed skull, toothless beak, and abundant teeth set back in the cheek. Walked and ran on two legs. Estimated length of 9 meters (30 ft).



## Therizinosaurus cheloniformis

*   **Geological Period:** Late Cretaceous (late Campanian-early Maastrichtian stages, approximately 70 million years ago).
*   **Habitat:** Mongolia. Alluvial plains (flat regions created by sediment deposition by rivers). Wetter climate than earlier periods.
*   **Anatomical Features:** Large plant-eating theropod that walked on two legs. Most distinctive feature: gigantic unguals (claws) on each of the three digits of its hands. Small head, long neck, short tail, and a large, bulky body. Elongated, often curved claws. Robust postcranial skeletons.



## Maiasaura peeblesorum

*   **Geological Period:** Late Cretaceous (mid to late Campanian, around 76.7 million years ago).
*   **Habitat:** North America (Canada and United States). Coastal and floodplain environments with abundant low vegetation. Thrived in a warm climate with lush forests.
*   **Anatomical Features:** Duck-billed hadrosaur. Adults walked on all fours, young animals on hind legs. Small crest in front of its eyes. Large, flat-headed. Approximately 9 meters (30 ft) long and 2.5 meters (8.2 ft) high.



## Utahraptor ostrommaysorum

*   **Geological Period:** Early Cretaceous (Barremian age, around 125 million years ago).
*   **Habitat:** North America (Utah). Plains.
*   **Anatomical Features:** Large raptor dinosaur. Bulky trunk, shorter legs, long arms, large head, and long tail. Large "killing claw" on its second toe. Jaws lined with small, serrated teeth. Phylogenetic evidence suggests feathers. Approximately 5.5-6 meters (18-20 feet) long.



## Gallimimus bullatus

*   **Geological Period:** Late Cretaceous (Maastrichtian stage, around 70 million years ago).
*   **Habitat:** Mongolia (Nemegt Formation). Varied habitats from arid desert to moist fern forests.
*   **Anatomical Features:** Bipedal, ostrich-like theropod. Long, slender neck and a small, narrow head. Long arms and generally elongated body. Toothless beak. Skeletal pneumaticity (hollow bones). Long and slender pubis ending in a pubic boot. Hind limbs adapted for speed. Approximately 5.5 to 8 meters (18 to 26 feet) long.



## Plateosaurus engelhardti

*   **Geological Period:** Late Triassic (Norian to Rhaetian stages, approximately 214 to 204 million years ago).
*   **Habitat:** Central Europe (Germany). Likely inhabited environments with diverse vegetation.
*   **Anatomical Features:** Bipedal herbivore. Small skull on a long, flexible neck. Sharp but plump plant-crushing teeth. Powerful hind limbs, short but muscular forelimbs. Long, whip-like tail. Exhibited developmental plasticity.



## Protoceratops andrewsi

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 83.6 to 72.1 million years ago).
*   **Habitat:** Mongolia (Gobi Desert). Arid environments.
*   **Anatomical Features:** Herbivorous ceratopsian. Lacked the large horns of later species but had a distinct bump above its nostrils and thickened bone over its eye sockets. Large head with a powerful beak and teeth for clipping and tearing plants. Quadrupedal. Elongated blade-like scapula. Approximately 1.8 to 2.5 meters (6 to 8 feet) long.



## Dilophosaurus wetherilli

*   **Geological Period:** Early Jurassic (Sinemurian to Pliensbachian stages, approximately 193 to 183 million years ago).
*   **Habitat:** North America. Likely inhabited forested and swampy areas.
*   **Anatomical Features:** Bipedal, carnivorous theropod. Distinctive pair of longitudinal, arched crests on its skull, likely covered in keratin. Narrow snout with a gap or kink below the nostril. Long, thin, curved teeth. Elongated, low, narrow skull. Over 20 feet long.



## Dryosaurus altus

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 155 to 145 million years ago).
*   **Habitat:** Western North America (Wyoming, Utah). Likely inhabited vast floodplains, river-lining forests, and savannahs. Environment included tree fern forests, prairies, and araucaria trees.
*   **Anatomical Features:** Small, bipedal ornithopod. Long neck, long slender legs, and a long, stiff tail. Small, narrow head with a beak-like mouth for cropping vegetation. Five fingers on each hand. Enlarged abdominal cavity, possibly for fermenting vegetation. Approximately 2.5 to 4.3 meters (8.2 to 14.1 feet) long.



## Ouranosaurus nigeriensis

*   **Geological Period:** Early Cretaceous (Aptian stage, approximately 125 to 113 million years ago).
*   **Habitat:** Niger, Africa. Inland floodplains (riparian zones), fluvial sandstones, and sand dunes.
*   **Anatomical Features:** Herbivorous iguanodont dinosaur. Most spectacular feature: tall neural spines along the dorsal, sacral, and caudal vertebrae, forming a sail-like structure. Measured about 7 meters (23-27 feet) long and weighed about 2-4 tons.



## Mononykus olecranus

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 70 million years ago).
*   **Habitat:** Mongolia (Gobi Desert). Desert plains.
*   **Anatomical Features:** Small, bird-like, likely feathered dinosaur. Lightly built with long, thin legs adapted for speed. Highly reduced and specialized forelimbs with a single large claw, likely used for foraging termite mounds or other insects. Small skull with small, pointed teeth. Biconvex posterior dorsal vertebra and keeled posterior synsacral vertebrae. Approximately 1 to 1.2 meters long.



## Edmontosaurus annectens

*   **Geological Period:** Late Cretaceous (Maastrichtian age, 73 to 66 million years ago).
*   **Habitat:** Western North America. Coastal and floodplain environments, coal seams, lagoons, and swamps.
*   **Anatomical Features:** Large duck-billed hadrosaur. Extremely long and low skull, approximately 1.18 meters (3 feet, 11 inches) long. Mouth resembled a duck's beak. Dental batteries in the posterior region of the mouth for slicing and grinding vegetation. Thickly muscled neck and tail. Up to 12 meters (39 ft), potentially up to 15 meters (49 ft) in length.



## Compsognathus longipes

*   **Geological Period:** Late Jurassic (Tithonian stage, approximately 150 to 145 million years ago).
*   **Habitat:** Europe (Germany, France, possibly Portugal). Likely inhabited areas with at least 48% sand composition, suggesting agility and speed. Coastal environments.
*   **Anatomical Features:** Small, bipedal, carnivorous theropod. Slender body with long hind legs and a long tail for balance. Long neck and tiny forelimbs. Approximately 0.7 to 1.4 meters (28 inches to 4.6 feet) long.



## Megalosaurus bucklandii

*   **Geological Period:** Middle Jurassic (Bathonian stage, approximately 166 million years ago).
*   **Habitat:** Southern England, also found in France and Portugal. Habitat ranged from dense forests to open plains.
*   **Anatomical Features:** Large bipedal theropod. Rather large head with long, curved, carnivorous teeth. Robust and heavily muscled body. Long tail for balance. Big hind legs, saurischian (lizard-like) hips. Short arms with three-fingered hands and sharp claws. Bulky body and heavy bones. Approximately 9 meters (30 ft) long and 3 meters (10 ft) tall.



## Herrerasaurus ischigualastensis

*   **Geological Period:** Late Triassic (Carnian stage, approximately 231 to 225 million years ago).
*   **Habitat:** Northwestern Argentina (Ischigualasto Formation). Likely inhabited forested and riverine environments.
*   **Anatomical Features:** Early saurischian dinosaur. Bipedal with strong hind limbs, short thighs, and long feet. Thin, long skull with rows of sharp, recurved teeth. Unique double-hinged jaw allowing it to hold struggling prey. Approximately 2.5 to 6 meters (8 to 20 feet) long and weighed around 180 to 350 kg (400 to 770 lb).



## Concavenator corcovatus

*   **Geological Period:** Early Cretaceous (Barremian stage, approximately 130 to 125 million years ago).
*   **Habitat:** Spain (Las Hoyas fossil site). Wet, woodland areas of Spain and western Europe.
*   **Anatomical Features:** Carcharodontosaurian dinosaur. Distinctive pointed hump on its back (formed by elongated neural spines). Small protrusions on its forearms, similar to quill knobs found on modern birds, possibly indicating feathers. Approximately 6 meters (20 feet) long.



## Gasosaurus constructus

*   **Geological Period:** Middle Jurassic (Bathonian to Callovian stages, approximately 171.6 to 161.2 million years ago).
*   **Habitat:** Asia (Sichuan, China). Likely inhabited forested areas.
*   **Anatomical Features:** Mid-sized tetanuran theropod. Strong legs but short arms. Shares characteristics with both more developed tetanuran theropods and earlier non-tetanurans. Approximately 3.5 to 4 meters (11 to 13 ft) in length, weighing around 150 to 400 kg.



## Cryolophosaurus ellioti

*   **Geological Period:** Early Jurassic (Pliensbachian stage, approximately 190 to 183 million years ago).
*   **Habitat:** Antarctica. During this period, Antarctica was much warmer and greener, likely forested.
*   **Anatomical Features:** Large theropod. Distinctive, unique cranial crest formed primarily by the lacrimals, running transversely across the head. Pronounced constriction of the squamosal and jugal bones. The skeleton shows a mix of advanced and basal theropod characteristics. Approximately 6.5 meters (21 feet) long.



## Troodon formosus

*   **Geological Period:** Late Cretaceous (Campanian age, approximately 77 to 70 million years ago).
*   **Habitat:** North America (Montana, Alaska) and Asia (Heilongjiang, China). Diverse environments including floodplains, coastal plains, forested areas, woods, tundras, fields, meadows, grasslands, and lowlands.
*   **Anatomical Features:** Relatively small, bird-like theropod. Large eyes. Teeth are short but broad, with large serrations. Jaws meet in a broad, U-shaped curve. Small (about 50kg) carnivorous dinosaur. Anatomical features suggest it was a true predator.



## Eoraptor lunensis

*   **Geological Period:** Late Triassic (Carnian stage, approximately 231 million years ago).
*   **Habitat:** South America (Ischigualasto Formation, Argentina). Forested areas with gymnosperms (conifers and cycads) and ferns.
*   **Anatomical Features:** Small, speedy omnivore. Thin body, about 1 meter (3 feet) long. Ran digitigrade (on its toes), upright on its hind legs. Multiple tooth shapes. Serrated teeth. Grasping hands. Hollow bones and small fourth and fifth fingers. Lightly built skull with a slightly enlarged external naris and a spacious antorbital fossa. Disproportionately big eye sockets.



## Kentrosaurus aethiopicus

*   **Geological Period:** Late Jurassic (late Kimmeridgian and early Tithonian stages, approximately 152 million years ago).
*   **Habitat:** Africa (Tendaguru Formation, Tanzania). Likely inhabited forested and open areas.
*   **Anatomical Features:** Stegosaur. Double row of small plates running down its neck and back, gradually merging into spikes on the hip and tail. Long tail with many large spikes (thagomizer). Two large spines protruding from the shoulders. Robust hindlimbs and forelimbs. Approximately 4.5 meters (15 ft) long.



## Shunosaurus lii

*   **Geological Period:** Middle Jurassic (Lower Shaximiao Formation, approximately 163 to 159 million years ago).
*   **Habitat:** China (Sichuan Province). Likely inhabited forested and vegetated areas.
*   **Anatomical Features:** Basal sauropod dinosaur. Ladle-shaped teeth for cropping low-growing plants. Bony, clubbed tail for defense. Relatively short neck. Approximately 9 meters long and weighing 3 tons.



## Homalocephale calathocercos

*   **Geological Period:** Late Cretaceous (Maastrichtian stage, approximately 83 to 66 million years ago).
*   **Habitat:** Mongolia (Nemegt Formation). At the time, this region was likely characterized by diverse environments, not just dry deserts.
*   **Anatomical Features:** Pachycephalosaurid dinosaur. Flattened, wedge-shaped skull with a thickened cranial roof, lined with small, bony spikes and ridges on the top rear and cheeks. Unusually broad pelvis. Large eyes and rows of small, sharp teeth. Approximately 1.5 meters (5 feet) long.



## Camarasaurus supremus

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 155 to 145 million years ago).
*   **Habitat:** Western United States (Morrison Formation). Likely inhabited forested and open areas with diverse vegetation.
*   **Anatomical Features:** Large, herbivorous sauropod. Characterized by "chambered" vertebrae (pneumatic vertebrae). Small, square-shaped head with a short, round snout. Robust, spoon-shaped teeth for browsing a wide variety of plants. Arched and very squared skull with a blunt rostrum and many large fenestrae. Powerful legs, strong neck and tail. Approximately 18 meters (60 feet) long and weighing around 25 tons.



## Ceratosaurus nasicornis

*   **Geological Period:** Late Jurassic (Tithonian stage, approximately 153 to 145 million years ago).
*   **Habitat:** North America (Utah, Wyoming, Colorado, Oklahoma) and Europe (possibly Portugal) and Africa (possibly Tanzania). Preferred habitats likely included forested and open areas.
*   **Anatomical Features:** Medium-sized carnivorous theropod. Distinctive prominent nasal horn and two smaller horny bumps over each eye. Deep jaws with proportionally very long, blade-like teeth. Robust skull with increased ornamentation. Shortened arms. Approximately 5.5 to 6 meters (18 to 20 feet) long.



## Euoplocephalus tutus

*   **Geological Period:** Late Cretaceous (Campanian to Maastrichtian stages, approximately 76 to 66 million years ago).
*   **Habitat:** North America (western United States and Canada). Thrived in woodland and wetland habitats, vast floodplains.
*   **Anatomical Features:** Giant, heavily armored herbivore. Low-slung, very flat and wide body. Short neck, robust forelimbs, and longer hindlimbs. Head had a short drooping snout with a horny beak. Rounded club at the end of its tail. Covered in bony plates and spikes. Approximately 6-7 meters long.



## Ornithomimus edmontonicus

*   **Geological Period:** Late Cretaceous (Maastrichtian age, approximately 70 million years ago).
*   **Habitat:** North America (Canada). Likely inhabited diverse environments including floodplains and coastal regions.
*   **Anatomical Features:** Swift, bipedal, ostrich-like theropod. Covered in feathers, including primitive, down-like feathers and shafted feathers on wings. Small toothless beak, possibly indicating an omnivorous diet. Long slender forearms, very slender, straight hand and foot claws. Shorter torso compared to other ornithomimids. Long legs adapted for speed. Approximately 3.6 meters (12 feet) long and 2.1 meters (7 feet) tall.



## Rajasaurus narmadensis

*   **Geological Period:** Late Cretaceous (Maastrichtian stage, approximately 69 to 66 million years ago).
*   **Habitat:** Western India (Lameta Formation, Narmada River Valley). Lush and green region by the Tethys Sea, filled with forests and rivers.
*   **Anatomical Features:** Abelisaurid theropod. Distinctive horn on its head. Long body, almost nonexistent arms, and thick, powerful legs. Muscular body and powerful hind limbs for speed and agility. Strong neck and jaw muscles. Approximately 7.6 to 9 meters (25 to 30 feet) long.



## Massospondylus carinatus

*   **Geological Period:** Early Jurassic (Hettangian to Pliensbachian ages, approximately 200 to 183 million years ago).
*   **Habitat:** Southern Africa (Elliot Formation). Diverse environments.
*   **Anatomical Features:** Prosauropod dinosaur. Long neck and tail, small head, and a slender body. Primarily bipedal. Muscular front limbs, possibly for defense or digging. Enlarged thumb claw. Elongated necks and tails, small heads, and shortened forelimbs. Approximately 4–6 meters (13–20 ft) long.



## Scelidosaurus harrisonii

*   **Geological Period:** Early Jurassic (Sinemurian to Pliensbachian stages, approximately 194 to 183 million years ago).
*   **Habitat:** Southern England. Likely inhabited forests covering islands in the former British Sea.
*   **Anatomical Features:** Lightly armored ornithischian dinosaur. Long horizontal rows of keeled oval scutes (osteoderms) along the neck, back, and tail. Three prominent longitudinal rows of keeled osteoderms on the back and flanks. Small, edentulous rostral beak with a row of five heterodont premaxillary teeth behind it. Serrated teeth for cutting vegetation. Entire body protected by skin anchoring stud-like bony spikes and plates. Approximately 3.8 meters (12.5 feet) long.



## Struthiomimus altus

*   **Geological Period:** Late Cretaceous (Campanian to Maastrichtian stages, approximately 76 to 66 million years ago).
*   **Habitat:** North America (Canada, Mexico). Roamed open plains and scrub, inhabited diverse environments including floodplains and coastal regions.
*   **Anatomical Features:** Long-legged, bipedal, ostrich-like dinosaur. Covered in feathers. Small head compared to its body size. Toothless beak. Long slender neck. Elongated lower leg, substantially longer than its upper leg, indicating speed. Long slender forearms, very slender, straight hand and foot claws. Approximately 4 meters (14 ft) long and 1.4 meters (4.6 ft) tall at the hips.



## Torvosaurus tanneri

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 153 to 148 million years ago).
*   **Habitat:** North America (Morrison Formation) and Europe (Portugal). Likely inhabited forested and open areas.
*   **Anatomical Features:** Large carnivorous megalosaurid theropod. Large skull (up to 115 cm) with teeth up to 10 cm. Robust build. Tibial circumference to length index of 47. Approximately 10 meters (33 feet) long.



## Oviraptor philoceratops

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 80 to 75 million years ago).
*   **Habitat:** Mongolia (Djadokhta Formation). Desert environment.
*   **Anatomical Features:** Small, bird-like, feathered theropod. Toothless beak. Distinctive head crest. Long, slender legs. Parrot-shaped head. Rib cage displayed several avian-like features. Approximately 1.5 to 2 meters (5 to 6.5 feet) long.



## Albertosaurus sarcophagus

*   **Geological Period:** Late Cretaceous (early Maastrichtian stage, approximately 73 to 70 million years ago).
*   **Habitat:** North America (Alberta, Canada). Lush, heavily vegetated semi-tropical environment, including delta and floodplain deposits, coal seams, lagoons, and swamps.
*   **Anatomical Features:** Bipedal predator. Massive head with dozens of large, sharp teeth (58 banana-shaped teeth). Short arms with two-fingered hands. Strong jaws. Scales were pebbly. Approximately 9-10 meters (30-33 feet) in length and weighing approximately 2-3 tons.



## Tyrannosaurus rex

*   **Geological Period:** Late Cretaceous (Maastrichtian age, approximately 72.7 to 66 million years ago).
*   **Habitat:** Western North America (Montana, Wyoming). Varied environments including forested areas and floodplains.
*   **Anatomical Features:** Large bipedal predator. Massive head with dozens of large, sharp teeth. Short, two-fingered forelimbs. Long, powerful tail for balance. Robust body structure. As it grew, forelimbs shrunk and skulls enlarged. Approximately 12 meters (40 feet) long and weighing up to 8 tons.



## Triceratops horridus

*   **Geological Period:** Late Cretaceous (Maastrichtian age, approximately 68 to 66 million years ago).
*   **Habitat:** Western North America. Preferred grassland and semi-arid regions, avoiding densely-forested areas.
*   **Anatomical Features:** Large quadrupedal herbivore. Distinctive large frill and three horns (one short nasal horn, two long brow horns). Sharp beak for snipping vegetation and rows of teeth for grinding tough plant material. Robust body. Approximately 7.9 to 9 meters (26 to 30 feet) long and weighing up to 12 tons.



## Velociraptor mongoliensis

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 75 to 71 million years ago).
*   **Habitat:** Mongolia (Djadokhta Formation, Gobi Desert). Arid environments.
*   **Anatomical Features:** Small, bipedal, feathered carnivore. Long tail. Enlarged sickle-shaped claw on each hindfoot. S-shaped neck. Skull up to 25 cm (9.8 inches) long, uniquely up-curved, concave on the top surface and convex on the lower. Jaws lined with 26–28 widely spaced teeth. Long, three-clawed hands. Approximately 1.5 to 2 meters (5 to 6.5 feet) long and weighing around 15 kg (33 lbs).



## Brachiosaurus altithorax

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 155.6 to 145.5 million years ago), possibly extending into the Early Cretaceous.
*   **Habitat:** North America, Africa, and Europe. Preferred forests and savannas with lots of tall trees.
*   **Anatomical Features:** Large sauropod. Long neck and a small head compared to its body size. Forelimbs longer than its hind legs, giving it a giraffe-like stance. Large trunk and columnar limbs. Disproportionately long neck and large trunk. Approximately 26 meters (85 feet) long and weighing up to 58 tons.



## Stegosaurus stenops

*   **Geological Period:** Late Jurassic (Kimmeridgian to Early Tithonian stages, approximately 155 to 145 million years ago).
*   **Habitat:** Western North America (Morrison Formation). Likely inhabited forested and open areas.
*   **Anatomical Features:** Large, heavily built, herbivorous quadruped. Distinctive double row of large, bony plates along its back and four spikes on its tail (thagomizer). Short forelimbs and long hind limbs, giving its back an arched appearance. Small head with a toothless beak in front and rows of teeth at the back of its jaws for grinding vegetation. Approximately 9 meters (30 feet) long.



## Allosaurus fragilis

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 155 to 145 million years ago).
*   **Habitat:** North America (Morrison Formation) and Portugal (Lourinhã Formation). Adapted to a range of climates, thriving in both lush and arid environments, semi-arid floodplains with distinct wet and dry seasons, and gallery forests.
*   **Anatomical Features:** Large bipedal predator. Light, robust skull with dozens of sharp, serrated teeth. Massive skull, serrated teeth, and gaping jaws. Snout narrower than the back part of the skull, which was stoutly built for predation. Short forelimbs with three-fingered hands. Approximately 8.5 to 12 meters (28 to 39 feet) long.



## Velociraptor mongoliensis

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 75 to 71 million years ago).
*   **Habitat:** Mongolia (Djadokhta Formation, Gobi Desert). Arid environments.
*   **Anatomical Features:** Small, bipedal, feathered carnivore. Long tail. Enlarged sickle-shaped claw on each hindfoot. S-shaped neck. Skull up to 25 cm (9.8 inches) long, uniquely up-curved, concave on the top surface and convex on the lower. Jaws lined with 26–28 widely spaced teeth. Long, three-clawed hands. Approximately 1.5 to 2 meters (5 to 6.5 feet) long and weighing around 15 kg (33 lbs).



## Ankylosaurus magniventris

*   **Geological Period:** Late Cretaceous (Maastrichtian stage, approximately 70 to 66 million years ago).
*   **Habitat:** North America. Browsed shrubbery in various environments including coastal habitats, coal seams, lagoons, swamps, and floodplains.
*   **Anatomical Features:** Large, heavily armored quadruped. Body covered in armor plates (osteoderms) with bony half-rings covering the neck. Large club on the end of its tail. Squat body. Approximately 6 to 8 meters (19.7 to 26.2 feet) in length.



## Spinosaurus aegyptiacus

*   **Geological Period:** Late Cretaceous (Cenomanian stage, approximately 99 to 93.5 million years ago).
*   **Habitat:** North Africa. Tidal flats (muddy or marshy areas covered by the sea) and mangrove forests.
*   **Anatomical Features:** Large carnivorous theropod. Most distinct feature is a tall dorsal sail formed from elongated neural spines. Long, narrow, crocodilian-like skull with nostrils near the eyes. Muscular shoulders and relatively long forearms. Exhibited a blend of terrestrial and aquatic adaptations. Approximately 15 to 18 meters (49 to 59 feet) long.



## Diplodocus longus

*   **Geological Period:** Late Jurassic (Kimmeridgian to Tithonian stages, approximately 154 to 145 million years ago).
*   **Habitat:** Western North America (Morrison Formation). Hot and dry, savannah-like environment with tree ferns and cycads.
*   **Anatomical Features:** Large sauropod. Extremely long neck and tail, four sturdy legs. Forelimbs slightly shorter than hind limbs. Two rows of bones on the underside of its tail. Peg-shaped teeth. Approximately 24.3 to 27 meters (80 to 90 feet) long, with about 80 vertebrae in its tail alone.



## Parasaurolophus walkeri

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 76.5 to 75.5 million years ago).
*   **Habitat:** Western North America (Alberta, New Mexico, Utah). Likely inhabited forested and wetland areas.
*   **Anatomical Features:** Hadrosaurid "duck-billed" dinosaur. Most distinctive feature is a long, narrow, backward-curving cranial crest that rises up from the skull, containing a simplified network of air passages. Approximately 9.5 meters (31 ft) long, with a skull about 1.6 meters (5.2 ft) long including the crest.



## Carnotaurus sastrei

*   **Geological Period:** Late Cretaceous (Campanian to Maastrichtian stages, approximately 72 to 69 million years ago).
*   **Habitat:** Patagonia, Argentina. Likely inhabited environments climatically similar to its ancestors, possibly open plains or forested areas.
*   **Anatomical Features:** Large, lightly built carnivorous theropod. Two thick horns above the eyes. Very deep skull with an unusually short snout and narrow head. Very small arms. Skin covered in small, non-overlapping scales interspersed with larger bumps or osteoderms. Powerful hind limbs. Approximately 7.6 meters (25 feet) long.



## Pachycephalosaurus wyomingensis

*   **Geological Period:** Late Cretaceous (Maastrichtian age, approximately 76 to 66 million years ago).
*   **Habitat:** Western North America (Montana, South Dakota, Wyoming). Varied habitats from coastal plains to dense forests, with a balance of open plains and sheltering structures.
*   **Anatomical Features:** Herbivorous pachycephalosaurid. Distinctive dome-shaped skull, up to 25-30 cm (10-12 inches) thick, surrounded by bony knobs and spikes. Thick neck, short forelimbs, long hindlimbs, bulky body, and a heavy tail held rigid by ossified tendons. Muzzle looked like a pointed beak with leaf-shaped teeth. Approximately 4.5 meters (15 feet) long.



## Giganotosaurus carolinii

*   **Geological Period:** Late Cretaceous (Cenomanian age, approximately 99.6 to 95 million years ago).
*   **Habitat:** Argentina. Primarily occupied open plains and forested regions with abundant rivers.
*   **Anatomical Features:** Large carnivorous theropod. Large head with a blunted chin. Skull larger than T. rex (1.6m vs 1.53m). Dozens of serrated teeth, up to 20 cm (8 inches) long. Long tail. Three-fingered hands. Approximately 12.2 to 13 meters (40 to 46 feet) long and 7 meters (23 feet) tall.



## Iguanodon bernissartensis

*   **Geological Period:** Early Cretaceous (Hauterivian to Aptian stages, approximately 139 to 122 million years ago).
*   **Habitat:** Europe (Belgium, England, Germany, Spain). Characterized by a warm climate with abundant water sources and lush vegetation.
*   **Anatomical Features:** Large herbivorous ornithopod. Distinctive large thumb spikes, possibly for defense. Long prehensile fifth fingers. Large skull with a toothless beak, but cheek teeth were closely bundled and diamond-shaped for grinding vegetation. Could switch between bipedal and quadrupedal movement. Approximately 10 meters (33 feet) long.



## Apatosaurus ajax

*   **Geological Period:** Late Jurassic (Tithonian stage, approximately 150 to 145 million years ago).
*   **Habitat:** North America (Morrison Formation, from Arizona to South Dakota, including Utah, Wyoming, and Oklahoma). Lived near gallery forests along riversides in otherwise semi-arid, prairie-like environments.
*   **Anatomical Features:** Large, heavily built herbivorous sauropod. Long neck and a long, whip-like tail. Forelimbs slightly shorter than hindlimbs. Sturdier and less elongated legs compared to other sauropods. Air sacs in vertebrae to lighten bones. Approximately 21 to 23 meters (70 to 75 feet) long.



## Coelophysis bauri

*   **Geological Period:** Late Triassic (Rhaetian stage, approximately 216 to 203 million years ago).
*   **Habitat:** Southwestern United States (Ghost Ranch, New Mexico). Likely inhabited semi-arid environments with seasonal rainfall.
*   **Anatomical Features:** Small, slenderly built, ground-dwelling, bipedal carnivore. Long, muscular rear legs terminating in three-toed, clawed feet. Shorter, thinner, but muscular arms with grasping hands. Long neck and tail for balance. Light, slender body adapted for running. Flat head. Approximately 3 meters (9.8 ft) long and weighing 23-32 kg (50-70 lbs).



## Corythosaurus casuarius

*   **Geological Period:** Late Cretaceous (Campanian stage, approximately 77 to 75.7 million years ago).
*   **Habitat:** North America (Alberta, Canada). Woodland forests and occasionally swampy areas.
*   **Anatomical Features:** Hadrosaurid (duck-billed) dinosaur. Hollow, bony crest on top of its long head in the shape of a helmet. Flat, duck-billed skull, toothless beak, and abundant teeth set back in the cheek. Walked and ran on two legs. Estimated length of 9 meters (30 ft), and a skull, including the crest, that is 70.8 centimeters (27.9 in) tall.



## Therizinosaurus cheloniformis

*   **Geological Period:** Late Cretaceous (Campanian to Maastrichtian stages, approximately 70 million years ago).
*   **Habitat:** Mongolia. Alluvial plains, flat regions created by the deposition of sediment by rivers. Wetter climate than earlier desert environments.
*   **Anatomical Features:** Large, plant-eating theropod that walked on two legs. Most distinctive feature: gigantic unguals (claws) on each of the three digits of its hands, up to 50 cm (20 inches) long. Small head, long neck, short tail, and a large, bulky body. Robust postcranial skeletons. Approximately 9 to 10 meters (30 to 33 feet) long.



## Maiasaura peeblesorum

*   **Geological Period:** Late Cretaceous (mid to late Campanian stage, approximately 76.7 million years ago).
*   **Habitat:** North America (Canada and United States). Coastal and floodplain environments with lush forests.
*   **Anatomical Features:** Large duck-billed hadrosaur. Small crest in front of its eyes. Young animals walked on hind legs, adults on all fours. Approximately 9 meters (30 ft) long and 2.5 meters (8.2 ft) high.



## Utahraptor ostrommaysorum

*   **Geological Period:** Early Cretaceous (Barremian to Aptian stages, approximately 139 to 134 million years ago).
*   **Habitat:** North America (Utah, Cedar Mountain Formation). Plains of North America.
*   **Anatomical Features:** Large dromaeosaurid (raptor) dinosaur. Bipedal, feathered carnivore. Jaws lined with small, serrated teeth. Large "killing claw" on its second toe. Bulky trunk, shorter legs, long arms, large head, and long tail. Approximately 5.5 to 6 meters (18 to 20 feet) long and weighing about 300 kg (660 lb).


