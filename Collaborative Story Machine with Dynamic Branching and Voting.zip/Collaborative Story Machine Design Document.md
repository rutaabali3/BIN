# Collaborative Story Machine Design Document

## 1. System Architecture

The Collaborative Story Machine will be implemented as a single-page application, adhering strictly to the constraints of using only HTML, CSS, JavaScript, and JSON for data. No external frameworks, libraries (beyond what's explicitly allowed like GSAP for animations), or backend services will be utilized.

### 1.1 File Structure

To achieve the single-file implementation goal, all HTML, CSS, and JavaScript will reside within a single `index.html` file. The JSON data will be managed in-memory by JavaScript and persisted to `localStorage` for demo purposes.

- `index.html`: Contains the main HTML structure, embedded CSS (`<style>` tags), and embedded JavaScript (`<script>` tags).
- `story_data_structure.json`: (For documentation purposes) Defines the expected JSON schema for story data.

### 1.2 Data Flow

1.  **Initialization:** On page load, JavaScript will attempt to load story data from `localStorage`. If no data exists, it will initialize with a default starting node.
2.  **Rendering:** The loaded JSON data will be used to dynamically render the story tree structure in the HTML.
3.  **User Interaction:**
    -   **Submission:** Users submit new story lines via a form. JavaScript validates input, creates a new story node object, updates the in-memory JSON, persists to `localStorage`, and re-renders the affected parts of the tree.
    -   **Voting:** Users click an upvote button on a node. JavaScript updates the `votes` count in the in-memory JSON, persists to `localStorage`, and visually updates the vote count on the node.
    -   **Navigation/Expansion:** JavaScript handles UI interactions for traversing branches, expanding/collapsing nodes, and sorting.

## 2. Data Structure (JSON)

The core of the application's data management revolves around a JSON structure that represents the story nodes and their relationships. This structure allows for a branching narrative, where each line can have multiple continuations.

```json
{
  "storyNodes": [
    {
      "lineID": "string",
      "parentID": "string" | null, // null for the root node
      "text": "string",
      "author": "string",
      "timestamp": "number", // Unix timestamp
      "votes": "number"
    }
  ],
  "metadata": {
    "lastLineID": "string" // To help generate unique IDs or track the latest ID
  }
}
```

### 2.1 Field Descriptions

| Field Name   | Type     | Description                                                                 |
| :----------- | :------- | :-------------------------------------------------------------------------- |
| `lineID`     | `string` | A unique identifier for each story line/node.                               |
| `parentID`   | `string` | The `lineID` of the node this line continues from. `null` for the initial node. |
| `text`       | `string` | The actual sentence or text of the story line.                              |
| `author`     | `string` | The name or pseudonym of the user who submitted the line.                   |
| `timestamp`  | `number` | Unix timestamp (milliseconds) when the line was created.                    |
| `votes`      | `number` | The number of upvotes this story line has received.                         |
| `metadata`   | `object` | Contains global information about the story, e.g., `lastLineID` for ID generation. |

## 3. LocalStorage Persistence

The entire JSON data object will be stored in `localStorage` under a specific key (e.g., `collaborativeStoryData`). This ensures that the story state persists across browser sessions, fulfilling the demo persistence requirement. Each update to the story data will trigger a save to `localStorage`.
